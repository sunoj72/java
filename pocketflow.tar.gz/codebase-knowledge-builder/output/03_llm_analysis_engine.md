# Chapter 3: LLM Analysis Engine

```markdown
# 3장: LLM 분석 엔진

다시 오신 것을 환영합니다! [2장: 튜토리얼 생성](02_tutorial_generation.md)에서는 튜토리얼 생성기가 마치 기술 작가처럼 코드베이스에 대한 원시 분석 자료를 가져와 구조화된 여러 챕터의 튜토리얼로 변환하는 과정을 살펴보았습니다. 핵심 개념(추상화) 식별, 연결 관계 분석, 챕터 순서 결정, 내용 작성과 같은 다양한 단계를 배웠습니다.

그런데 그 초기 "원시 분석" 자료는 어디서 왔을까요? 시스템은 코드의 어떤 부분이 중요하고 서로 어떻게 관련되어 있는지 어떻게 알았을까요? 이것이 바로 이번 장에서 다룰 **LLM 분석 엔진**이 수행하는 마법입니다!

## 문제: 복잡한 코드를 자동으로 이해하기

수많은 파일에 걸쳐 수천 줄의 코드가 있는 거대하고 낯선 코드베이스를 받았다고 상상해 보세요. 여러분의 임무는 초보자를 위해 가장 중요한 부분을 설명하는 튜토리얼을 작성하는 것입니다. 어디서부터 시작해야 할까요? 모든 코드를 읽는 데는 며칠 또는 몇 주가 걸릴 것입니다!

이것이 바로 우리 튜토리얼 생성기가 직면한 과제입니다. 사람이 몇 시간씩 코드를 읽지 않고도 코드베이스의 핵심 – 주요 구성 요소, 목적, 상호 작용 방식 – 을 빠르게 파악해야 합니다. 어떻게 이 이해 과정을 자동화할 수 있을까요?

## 우리의 해결책: 전문가 컨설턴트 (LLM 분석 엔진)

LLM 분석 엔진을 매우 빠르고 지식이 풍부한 **전문가 컨설턴트**라고 생각해보세요. 이 컨설턴트에게 프로젝트 문서 더미(코드베이스 파일)를 건네주면, 신속하게 내용을 읽고 핵심 아이디어를 식별하며, 어떻게 조립되는지 파악하고, 설명하기 가장 좋은 방법까지 제안할 수 있습니다.

이 엔진은 **대규모 언어 모델(Large Language Model, LLM)** – 방대한 양의 텍스트와 코드로 학습된 인공지능의 한 종류 – 을 사용합니다. LLM은 주어진 내용에 대해 패턴을 이해하고, 정보를 요약하며, 질문에 답하는 데 놀랍도록 뛰어납니다.

우리의 LLM 분석 엔진은 이 능력을 활용하여 다음을 수행합니다:

1.  **핵심 추상화 식별:** 코드를 읽고 가장 중요한 개념이나 구성 요소를 찾아냅니다 (2장에서 보았던 `IdentifyAbstractions` 노드에 필요합니다).
2.  **관계 분석:** 이러한 핵심 개념들이 어떻게 상호 작용하는지 파악합니다 (예: "구성 요소 A가 구성 요소 B를 사용한다", `AnalyzeRelationships` 노드에 필요합니다).
3.  **논리적 순서 결정:** 초보자에게 이러한 개념을 설명하기 위한 최적의 순서를 제안합니다 (`OrderChapters` 노드에 필요합니다).

본질적으로, LLM 분석 엔진은 [2장: 튜토리얼 생성](02_tutorial_generation.md) 프로세스가 최종 튜토리얼을 구축하는 데 사용하는 핵심적인 이해와 통찰력을 제공합니다.

## 작동 방식: 올바른 질문하기

LLM 분석 엔진은 단순히 마법처럼 코드를 이해하는 것이 아닙니다. 시스템의 다른 부분, 특히 **처리 노드**(Processing Nodes, 예: `IdentifyAbstractions`, `AnalyzeRelationships`, `OrderChapters` – [6장: 처리 노드](06_processing_nodes.md)에서 더 자세히 살펴볼 것입니다)가 이 엔진과 상호 작용해야 합니다.

이렇게 생각해보세요: 노드는 *어떤* 정보가 필요한지 아는 관리자와 같습니다. LLM 분석 엔진은 올바른 질문을 받으면 그 정보를 *찾아낼* 수 있는 컨설턴트입니다.

일반적인 작업 흐름은 다음과 같습니다:

1.  **질문 준비 (프롬프트):** 노드(예: `IdentifyAbstractions`)는 [4장: 코드베이스 크롤링](04_codebase_crawling.md) 단계에서 가져온 관련 코드 파일을 수집합니다. 그런 다음 LLM으로부터 필요한 정보를 얻기 위해 설계된 구체적인 질문, 즉 **프롬프트(prompt)** 를 만듭니다. 이 프롬프트에는 코드 맥락과 무엇을 식별하고 답변 형식을 어떻게 지정할지에 대한 명확한 지침이 포함됩니다.

    *간단한 프롬프트 예시 (추상화 식별용):*
    ```
    다음 코드 파일을 분석하세요:
    --- 파일 0: main.py ---
    # 코드 내용...
    --- 파일 1: utils.py ---
    # 코드 내용...

    핵심 추상화 5개를 식별하세요. 각각에 대해 이름,
    초보자 친화적인 설명, 관련 파일 인덱스를 제공하세요.
    출력은 YAML 형식으로 작성하세요.
    ```

2.  **전문가에게 질문하기 (`call_llm`):** 노드는 이 상세한 프롬프트를 `utils/call_llm.py`와 같은 헬퍼 함수에 전달합니다. 이 함수는 LLM 분석 엔진과의 핵심적인 소통 채널입니다.

3.  **LLM 처리:** `call_llm` 함수는 실제 대규모 언어 모델 서비스(예: Google의 Gemini)에 프롬프트를 보냅니다. LLM은 프롬프트와 제공된 코드 맥락을 읽고, 학습된 내용을 바탕으로 분석을 수행하며, 텍스트 기반 답변을 생성합니다.

4.  **답변 수신:** `call_llm` 함수는 LLM의 텍스트 응답을 다시 받습니다.

    *LLM 응답 예시 (YAML 형식):*
    ```yaml
    - name: 설정 로더
      description: 설정을 불러옵니다... 마치 설명서를 읽는 것과 같습니다.
      file_indices: [0]
    - name: 메인 실행기
      description: 프로세스를 시작합니다... 시작 버튼을 누르는 것과 같습니다.
      file_indices: [0, 1]
    # ... 더 많은 추상화 ...
    ```

5.  **분석 및 사용:** 원래 질문했던 노드는 `call_llm`으로부터 응답 텍스트를 받습니다. 그런 다음 이 텍스트를 분석하고(예: YAML 문자열을 파이썬 딕셔너리 리스트로 변환) 필요한 정보(이 경우 추상화 목록)를 추출합니다. 이 정보는 다른 노드가 사용할 수 있도록 `shared` 딕셔너리에 저장됩니다.

이 상호 작용을 보여주는 시퀀스 다이어그램입니다:

```mermaid
sequenceDiagram
    participant Node as 처리 노드 (예: IdentifyAbstractions)
    participant CallLLM as utils/call_llm.py
    participant LLMEngine as LLM 분석 엔진 (개념 + LLM 서비스)
    participant Shared as shared 딕셔너리

    Node->>Node: 코드 맥락으로 프롬프트 준비
    Node->>CallLLM: call_llm(prompt) 호출
    CallLLM->>LLMEngine: LLM API에 프롬프트 전송
    LLMEngine->>LLMEngine: 코드 분석 및 응답 생성
    LLMEngine-->>CallLLM: 텍스트 응답 반환
    CallLLM-->>Node: 텍스트 응답 반환
    Node->>Node: 응답 분석 (예: YAML)
    Node->>Shared: 분석 결과 저장 (예: 추상화 목록)
```

## 내부 들여다보기: `call_llm` 유틸리티

이 상호 작용을 가능하게 하는 핵심 코드는 `utils/call_llm.py` 유틸리티입니다. 이 유틸리티의 역할은 간단하지만 매우 중요합니다: LLM에 질문(프롬프트)을 보내고 답변을 반환하는 것입니다.

`call_llm`이 수행하는 작업을 매우 단순화해서 살펴보겠습니다:

```python
# --- utils/call_llm.py 단순화 버전 ---
import os
# 'genai'가 LLM 서비스 라이브러리라고 가정 (예: Google Gemini)
from google import genai
import logging # 호출 기록용
import json # 캐싱용

logger = logging.getLogger(__name__)
cache_file = "llm_cache.json" # 캐시 파일 이름

# LLM과 상호 작용하는 함수
def call_llm(prompt: str, use_cache: bool = True) -> str:
    """LLM에 프롬프트를 보내고 텍스트 응답을 반환합니다."""

    logger.info(f"LLM에 프롬프트 전송 (처음 50자): {prompt[:50]}...")

    # 캐시 확인 (활성화된 경우)
    if use_cache:
        cache = {}
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    cache = json.load(f)
            except Exception as e:
                logger.warning(f"캐시 로드 실패: {e}")
        if prompt in cache:
            logger.info("캐시에서 응답 반환")
            return cache[prompt] # 캐시에 있으면 바로 반환

    try:
        # 1. LLM 클라이언트 설정 (보통 API 키 필요)
        api_key = os.getenv("GEMINI_API_KEY") # 환경 변수에서 API 키 가져오기
        client = genai.Client(api_key=api_key)
        # 사용할 모델 이름 설정 (환경 변수 또는 기본값 사용)
        model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

        # 2. 지정된 모델에 프롬프트 전송
        response = client.models.generate_content(
            model=model_name,
            contents=[prompt] # 실제 질문/프롬프트 내용
        )

        # 3. 텍스트 답변 추출
        response_text = response.text
        logger.info("LLM으로부터 응답 수신 완료.")

        # 캐시 업데이트 (활성화된 경우)
        if use_cache:
            # 캐시 파일 다시 로드 (덮어쓰기 방지) 후 저장
            if os.path.exists(cache_file):
                 try:
                     with open(cache_file, 'r') as f: cache = json.load(f)
                 except: pass # 실패해도 계속 진행
            cache[prompt] = response_text
            try:
                with open(cache_file, 'w') as f: json.dump(cache, f)
            except Exception as e:
                 logger.error(f"캐시 저장 실패: {e}")

        return response_text

    except Exception as e:
        logger.error(f"LLM 호출 중 오류 발생: {e}")
        # 실제 상황에서는 재시도하거나 오류 메시지를 반환할 수 있음
        return "오류: LLM으로부터 응답을 받을 수 없습니다."

```

**설명:**

1.  **로깅:** 프롬프트가 전송되고 있음을 기록합니다 (디버깅에 유용).
2.  **캐싱 확인:** `use_cache`가 True이면, 이전에 똑같은 프롬프트에 대한 응답이 저장되어 있는지 확인합니다. 있다면 LLM을 호출하지 않고 저장된 응답을 바로 사용합니다. 이는 시간과 비용을 절약해줍니다!
3.  **설정:** LLM 서비스에 연결을 설정합니다. 종종 API 키(비밀번호와 같은 것)가 필요하며, 이는 보통 환경 변수(`os.getenv`)로 안전하게 저장됩니다. 사용할 LLM 모델도 지정합니다 (모델마다 기능과 비용이 다릅니다).
4.  **프롬프트 전송:** 핵심 동작입니다! 클라이언트 라이브러리(`client.models.generate_content`)를 사용하여 LLM 서비스에 `prompt` 문자열을 보냅니다.
5.  **응답 받기:** LLM으로부터 응답 객체를 받아 실제 텍스트 내용(`response.text`)을 추출합니다.
6.  **캐시 업데이트:** 캐싱이 활성화되어 있고 이전에 캐시에 없던 새로운 응답이라면, 나중을 위해 응답을 캐시 파일에 저장합니다.
7.  **반환:** 이 텍스트를 호출한 노드에 다시 전달합니다.
8.  **오류 처리:** LLM 호출이 실패할 경우를 대비한 기본적인 오류 처리 로직을 포함합니다.

이 `call_llm` 함수는 다리 역할을 하여, 우리 시스템의 다른 부분(노드들)이 LLM API 상호 작용의 복잡한 세부 사항을 알 필요 없이 LLM의 분석 능력을 활용할 수 있도록 합니다.

## 결론

LLM 분석 엔진은 코드베이스를 이해하는 측면에서 우리 튜토리얼 생성기의 "두뇌"입니다. 마치 전문가 컨설턴트처럼, 제공된 코드를 분석하기 위해 대규모 언어 모델을 사용합니다. 다른 처리 노드들이 제기하는 특정 질문(프롬프트)에 답함으로써 핵심 추상화를 식별하고, 관계를 분석하며, 논리적인 설명 순서를 결정합니다. `call_llm` 유틸리티를 통해 촉진되는 이 자동화된 분석은 [2장: 튜토리얼 생성](02_tutorial_generation.md) 프로세스가 의미 있고 구조화된 튜토리얼을 만드는 데 필요한 필수적인 통찰력을 제공합니다.

이제 시스템이 코드를 어떻게 *이해*하는지 알았습니다. 그런데 애초에 시스템은 어떻게 GitHub이나 로컬 폴더와 같은 다른 소스에서 코드 파일을 가져왔을까요? 그것이 바로 다음에 살펴볼 코드베이스 크롤러의 역할입니다!

[4장: 코드베이스 크롤링](04_codebase_crawling.md)으로 넘어가 봅시다.

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)