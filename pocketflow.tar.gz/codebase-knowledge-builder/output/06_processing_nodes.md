# Chapter 6: Processing Nodes

```markdown
# 6장: 처리 노드

다시 오신 것을 환영합니다! [5장: 워크플로우 파이프라인 (PocketFlow)](05_workflow_pipeline__pocketflow_.md)에서는 전체 튜토리얼 생성 과정을 조율하는 "조립 라인 관리자"(PocketFlow)에 대해 배웠습니다. 코드를 가져오는 것부터 최종 파일을 작성하는 것까지 모든 단계가 올바른 순서로 진행되도록 보장하는 역할을 했죠.

하지만 그 개별 단계들은 *무엇*일까요? 우리 조립 라인을 따라 늘어선 전문화된 작업 스테이션은 무엇일까요? 이번 장에서는 바로 그것, **처리 노드(Processing Nodes)**에 대해 자세히 알아볼 것입니다.

## 문제: 실제 작업 수행하기

다시 자동차 공장 비유를 생각해 봅시다. 조립 라인 관리자는 흐름을 지시하지만, 직접 자동차를 만들지는 않습니다. 프레임을 용접하는 작업자, 엔진을 설치하는 작업자, 차체를 도색하는 작업자 등 다양한 스테이션에 전문화된 작업자나 로봇 팔이 필요합니다. 각 스테이션은 구체적이고 잘 정의된 작업을 수행합니다.

마찬가지로, 우리의 워크플로우 파이프라인 관리자(PocketFlow)는 작업의 *순서*는 알지만, 실제로 *작업을 수행*할 개별 구성 요소가 필요합니다. "GitHub에서 코드 가져오기", "LLM에게 개념 식별 요청하기", 또는 "챕터들을 최종 출력으로 결합하기"와 같은 이러한 개별 작업을 어떻게 정의할까요?

## 우리의 해결책: 전문 작업자 (처리 노드)

**처리 노드**는 우리 튜토리얼 생성 조립 라인의 개별 작업자들입니다. 각 노드는 하나의 특정 작업을 수행하도록 설계된 독립적인 단위입니다.

이전 장에서 만났던 노드의 몇 가지 예시는 다음과 같습니다:

*   `FetchRepo`: GitHub 저장소에서 코드를 가져옵니다 ([4장: 코드베이스 크롤링](04_codebase_crawling.md)).
*   `FetchLocal`: 로컬 폴더에서 코드를 가져옵니다 ([4장: 코드베이스 크롤링](04_codebase_crawling.md)).
*   `IdentifyAbstractions`: LLM에게 핵심 개념을 찾아달라고 요청합니다 ([2장: 튜토리얼 생성](02_tutorial_generation.md), [3장: LLM 분석 엔진](03_llm_analysis_engine.md)).
*   `AnalyzeRelationships`: LLM에게 개념들이 어떻게 관련되는지 물어봅니다 ([2장](02_tutorial_generation.md), [3장](03_llm_analysis_engine.md)).
*   `OrderChapters`: LLM에게 최적의 챕터 순서를 물어봅니다 ([2장](02_tutorial_generation.md), [3장](03_llm_analysis_engine.md)).
*   `WriteChapters`: LLM에게 각 챕터의 내용을 작성하도록 요청합니다 ([2장](02_tutorial_generation.md)).
*   `CombineTutorial`: 모든 조각을 모아 최종 튜토리얼 파일을 작성합니다 ([2장](02_tutorial_generation.md)).

각 노드는 전문가처럼 행동합니다. 특정 입력을 받아 고유한 작업을 수행하고 특정 출력을 생성하며, 이 출력은 종종 파이프라인의 다음 노드에서 사용됩니다.

## 노드 내부 들여다보기: 준비-실행-후처리 사이클

노드는 실제로 어떻게 작업을 수행할까요? 우리 프로젝트의 대부분 노드는 PocketFlow에 의해 관리되는 간단한 세 단계 라이프사이클을 따릅니다:

1.  **`prep(shared)` (준비 / 준비하기):**
    *   **목적:** 작업에 필요한 모든 재료(데이터)를 중앙 `shared` 딕셔너리에서 가져옵니다.
    *   **비유:** 제빵사가 빵을 굽기 전에 식료품 저장실(`shared` 딕셔너리)에서 밀가루, 설탕, 계란(입력)을 모으는 것과 같습니다.
    *   **입력:** 현재 `shared` 딕셔너리.
    *   **출력:** `exec` 단계에 필요한 특정 데이터를 반환합니다.

2.  **`exec(prep_res)` (실행 / 작업하기):**
    *   **목적:** 준비된 재료를 사용하여 노드의 핵심 작업을 수행합니다. 이는 헬퍼 함수(예: `crawl_local_files` 또는 `call_llm`) 호출, 데이터 처리, 또는 계산 실행 등을 포함할 수 있습니다.
    *   **비유:** 제빵사가 재료를 섞고 케이크를 오븐에 넣습니다(주요 작업 수행).
    *   **입력:** `prep` 단계에서 반환된 데이터 (`prep_res`).
    *   **출력:** 작업 결과를 반환합니다 (예: 가져온 파일 목록, 식별된 추상화, 작성된 챕터 내용).

3.  **`post(shared, prep_res, exec_res)` (후처리 / 결과 저장하기):**
    *   **목적:** `exec` 단계의 결과를 가져와 다시 `shared` 딕셔너리에 저장하여 후속 노드에서 사용할 수 있도록 합니다. 정리 작업이나 최종 로깅을 수행할 수도 있습니다.
    *   **비유:** 제빵사가 완성된 케이크(결과)를 가져와 다음 단계(장식)를 위해 식힘망(`shared` 딕셔너리)에 놓습니다.
    *   **입력:** `shared` 딕셔너리, `prep`의 데이터 (`prep_res`), 그리고 `exec`의 결과 (`exec_res`).
    *   **출력:** `shared` 딕셔너리를 제자리에서 업데이트합니다.

PocketFlow는 워크플로우의 각 노드에 대해 이 세 가지 메서드를 순서대로 호출합니다.

다음은 PocketFlow가 이 사이클을 사용하여 노드와 상호 작용하는 방식을 보여주는 다이어그램입니다:

```mermaid
sequenceDiagram
    participant PF as PocketFlow 엔진
    participant Node as 처리 노드
    participant Shared as shared 딕셔너리

    Note over PF, Node: 노드 처리 시작...
    PF->>Node: node.prep(shared) 호출
    Node->>Shared: 필요한 데이터 읽기 (예: repo_url)
    Node-->>PF: 준비된 데이터 반환 (prep_res)
    PF->>Node: node.exec(prep_res) 호출
    Note right of Node: 핵심 작업 수행...<br/>(예: crawl_local_files, call_llm 호출)
    Node-->>PF: 결과 반환 (exec_res)
    PF->>Node: node.post(shared, prep_res, exec_res) 호출
    Node->>Shared: 결과를 다시 쓰기 (예: shared["files"] = exec_res)
    Node-->>PF: 후처리 완료
    Note over PF, Node: 노드 처리 완료!
```

## 코드 엿보기: `nodes.py`

우리의 모든 전문 작업자(노드)는 `nodes.py` 파일에 파이썬 클래스로 정의되어 있습니다. 이들은 `pocketflow.Node` (또는 때때로 `pocketflow.BatchNode`)를 상속하고 `prep`, `exec`, `post` 메서드를 구현합니다.

간단한 예제를 살펴보겠습니다:

**예제 1: `FetchLocal` (간소화 버전)**

이 노드는 로컬 디렉토리에서 파일을 가져옵니다.

```python
# --- nodes.py의 간소화 버전 ---
from pocketflow import Node
from utils.crawl_local_files import crawl_local_files # 헬퍼 함수

class FetchLocal(Node):
    # 단계 1: 준비 - shared 딕셔너리에서 지침 가져오기
    def prep(self, shared):
        print("FetchLocal: 준비 중...")
        # 필요한 정보(경로, 필터)를 shared에서 가져옴
        config = {
            "repo_url": shared["repo_url"],
            "include_patterns": shared["include_patterns"],
            # ... 다른 필터들 ...
        }
        return config # exec에 필요한 설정 반환

    # 단계 2: 실행 - 사서 유틸리티 호출
    def exec(self, prep_res):
        print(f"FetchLocal: {prep_res['repo_url']} 크롤링 실행 중...")
        # 준비된 설정으로 실제 크롤링 함수 호출
        result = crawl_local_files(**prep_res) # 설정을 직접 전달
        # 파일 목록 가져오기: [(경로1, 내용1), ...]
        files_list = list(result.get("files", {}).items())
        print(f"FetchLocal: {len(files_list)}개 파일 가져옴.")
        return files_list # 가져온 파일 목록 반환

    # 단계 3: 후처리 - 결과를 shared에 저장
    def post(self, shared, prep_res, exec_res):
        print("FetchLocal: 결과 저장 중...")
        # (경로, 내용) 튜플 목록을 shared 딕셔너리에 저장
        shared["files"] = exec_res # exec_res는 files_list임
        print("FetchLocal: 완료.")
```

*   `prep`: `shared` 딕셔너리에서 `repo_url` 및 필터와 같은 설정을 읽습니다.
*   `exec`: 준비된 설정을 사용하여 `crawl_local_files` 함수([4장](04_codebase_crawling.md)의 실제 파일 가져오기 로직)를 호출합니다. 찾은 파일 목록을 반환합니다.
*   `post`: `exec`에서 반환된 파일 목록 (`exec_res`)을 가져와 `shared` 딕셔너리에 `"files"`라는 키 아래에 저장합니다.

**예제 2: `IdentifyAbstractions` (간소화 버전)**

이 노드는 LLM에게 핵심 개념을 식별하도록 요청합니다.

```python
# --- nodes.py의 간소화 버전 ---
from pocketflow import Node
from utils.call_llm import call_llm # LLM 호출 헬퍼

class IdentifyAbstractions(Node):
    # 단계 1: 준비 - 파일 데이터 가져와서 컨텍스트 준비
    def prep(self, shared):
        print("IdentifyAbstractions: 준비 중...")
        files_data = shared["files"] # 이전 단계에서 가져온 파일들
        # 실제로는 형식화된 컨텍스트와 프롬프트 세부 정보 생성
        context_for_llm = "files_data 기반 코드 컨텍스트..."
        prompt_details = "핵심 추상화 식별..."
        print("IdentifyAbstractions: LLM 컨텍스트 준비 완료.")
        # 실제로는 파일 개수 등 더 많은 정보를 반환할 수 있음
        return context_for_llm, prompt_details, len(files_data)

    # 단계 2: 실행 - LLM 호출
    def exec(self, prep_res):
        context, details, file_count = prep_res
        print("IdentifyAbstractions: LLM 호출 실행 중...")
        # 전체 프롬프트 구성 및 LLM 호출
        prompt = f"{context}\n\n{details}"
        response_text = call_llm(prompt) # 전문가에게 물어보기!
        # 실제로는 YAML 응답 파싱
        parsed_abstractions = [{"name": "예제", "files": [0]}] # 임시 파싱 결과
        print(f"IdentifyAbstractions: {len(parsed_abstractions)}개 추상화 수신.")
        return parsed_abstractions # 추상화 목록 반환

    # 단계 3: 후처리 - 추상화 저장
    def post(self, shared, prep_res, exec_res):
        print("IdentifyAbstractions: 결과 저장 중...")
        # exec_res의 추상화 목록을 shared에 저장
        shared["abstractions"] = exec_res
        print("IdentifyAbstractions: 완료.")
```

*   `prep`: `FetchLocal` (또는 `FetchRepo`)이 저장한 파일 목록(`shared["files"]`)을 가져옵니다. LLM에 필요한 텍스트 컨텍스트와 지침을 준비합니다.
*   `exec`: 준비된 프롬프트로 `call_llm` 함수([3장](03_llm_analysis_engine.md)의 함수)를 호출합니다. LLM의 응답을 받아 구조화된 추상화 목록으로 파싱합니다.
*   `post`: `exec`에서 반환된 추상화 목록 (`exec_res`)을 가져와 `shared` 딕셔너리에 `"abstractions"`라는 키 아래에 저장하여 `AnalyzeRelationships` 노드가 사용할 수 있도록 준비합니다.

**`BatchNode`에 대한 참고 (`WriteChapters`)**

`WriteChapters`가 `BatchNode`를 상속하는 것을 눈치챘을 수 있습니다. 이는 *동일한* 실행 로직을 *여러* 항목에 대해 수행해야 할 때 사용되는 특별한 유형의 노드입니다.

*   `prep`: 처리할 항목 *목록*을 준비합니다 (예: 각 항목이 특정 챕터 하나를 작성하는 데 필요한 세부 정보를 포함하는 목록).
*   `exec`: `prep`에서 준비된 목록의 *각 항목에 대해 한 번씩* 실행됩니다.
*   `post`: 각 `exec` 호출에서 나온 결과 *목록*을 받습니다.

마치 한 명의 작업자(`WriteChapters` 노드)가 챕터 개요 묶음(`prep` 결과)을 받아 각 챕터를 개별적으로 작성하고(`exec`가 여러 번 호출됨), 그런 다음 완성된 모든 챕터를 함께 묶는 것과 같습니다 (`post`가 결과 목록을 받음).

## 결론

처리 노드는 우리 워크플로우 파이프라인의 기본적인 구성 요소입니다. 이들은 조립 라인의 전문 작업자로서, 코드 가져오기, LLM으로 분석하기, 또는 출력 파일 작성과 같은 고유한 작업을 각각 수행합니다. 대부분의 노드는 PocketFlow에 의해 관리되는 `prep` -> `exec` -> `post` 라이프사이클을 따르며, `shared` 딕셔너리를 사용하여 입력을 받고 출력을 저장하여 데이터가 한 단계에서 다음 단계로 원활하게 흐르도록 보장합니다.

노드를 이해하면 튜토리얼 생성이라는 복잡한 작업이 어떻게 더 작고 관리 가능한 단계로 나뉘는지 알 수 있으며, 각 단계는 `nodes.py`에 집중된 파이썬 클래스로 구현됩니다.

이번 장을 통해 튜토리얼 생성기의 모든 핵심 개념적 구성 요소(설정, 전체 생성 프로세스, LLM 엔진, 코드베이스 크롤링, 워크플로우 파이프라인, 그리고 작업을 수행하는 처리 노드)를 다루었습니다. 이제 이 프로젝트가 어떻게 작동하는지에 대한 탄탄한 기초를 갖추게 되었습니다!

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)