# Chapter 1: Configuration & Execution

튜토리얼 생성기에 오신 것을 환영합니다! 이런 복잡한 소프트웨어가 실제로 어떻게 *실행*되기 시작하는지 궁금เคย본 적 있나요? 어떤 코드 프로젝트에 대한 튜토리얼을 만들고 싶은지, 또는 최종 튜토리얼 파일을 어디에 저장하고 싶은지 어떻게 알려줄까요? 이 장에서 바로 그 내용을 다룹니다!

이 프로젝트를 코드베이스용 튜토리얼을 만드는 정교한 조립 라인이라고 생각해보세요. 첫 번째 단계인 "설정 및 실행"은 그 조립 라인의 주 제어판과 같습니다. 운영자인 여러분이 모든 중요한 매개변수(예: *어떤* 제품을 만들 것인가? - 어떤 코드베이스?)를 설정하고 큰 "시작" 버튼을 누르는 곳입니다.

**우리의 목표:** 여러분의 컴퓨터에 로컬로 `my_awesome_project`라는 폴더에 작은 프로젝트가 있고, 이를 위한 튜토리얼을 생성하여 `my_tutorial`이라는 새 폴더에 결과를 저장하고 싶다고 상상해 봅시다. 생성기에게 정확히 그렇게 하도록 어떻게 지시할 수 있을까요?

## 명령줄 인수란 무엇인가요?

대부분의 프로그램은 시작하기 위해 몇 가지 초기 지침이 필요합니다. 복잡한 그래픽 인터페이스 대신 많은 개발자 도구는 **명령줄**(종종 터미널 또는 명령 프롬프트라고 불리는 텍스트 기반 창)을 사용합니다. 여러분이 명령을 입력하면 컴퓨터가 응답합니다.

튜토리얼 생성기를 실행할 때, 명령어 바로 뒤에 추가 정보를 덧붙일 수 있는데, 이를 **명령줄 인수(command-line arguments)**라고 합니다. 이것들은 여러분이 미리 제공하는 설정이나 옵션처럼 작동합니다.

마치 비디오 게임을 시작하기 전에 선호도를 설정하는 것과 같습니다: 쉬운 모드 또는 어려운 모드를 원하나요? 어떤 캐릭터로 플레이할 건가요? 명령줄 인수를 사용하면 다음과 같은 것들을 지정할 수 있습니다:

*   **코드는 어디에 있나요?** (GitHub에 있나요? 아니면 로컬 폴더인가요?)
*   **출력은 어디로 가야 하나요?**
*   **포함하거나 무시할 특정 파일이 있나요?**
*   **특별한 접근 권한(예: GitHub 토큰)이 필요한가요?**

## 생성기 실행하기 (`main.py`)

우리 조립 라인의 주 진입점, 즉 "시작" 버튼은 `main.py`라는 파일입니다. 명령줄에서 Python을 사용하여 이 파일을 실행합니다.

인수(우리의 설정)를 처리하기 위해 `main.py`는 `argparse`라는 표준 Python 도구를 사용합니다. 우리가 사용할 수 있는 몇 가지 인수가 어떻게 정의되는지 보여주는 간단한 코드 조각을 살펴봅시다:

```python
# --- 파일: main.py ---
import argparse

# 인수 파서 생성
parser = argparse.ArgumentParser(description="튜토리얼 생성...")

# 'repo_url' 인수 정의 (필수)
parser.add_argument("repo_url", help="공개 GitHub 리포지토리 URL 또는 소스 파일의 로컬 경로.")

# 'output' 인수 정의 (선택 사항, 기본값 있음)
parser.add_argument("-o", "--output", default="output", help="출력 기본 디렉토리 (기본값: ./output).")

# 'include' 및 'exclude' 인수 정의 (선택 사항)
parser.add_argument("-i", "--include", nargs="+", help="포함할 파일 패턴...")
parser.add_argument("-e", "--exclude", nargs="+", help="제외할 파일 패턴...")

# ... 다른 인수들이 여기에 정의됨 ...

# --- 이 부분은 main()에서 나중에 발생합니다 ---
# 사용자가 제공한 인수를 실제로 파싱합니다
# args = parser.parse_args()
```

*   `argparse.ArgumentParser(...)`: 인수를 관리하는 도우미 객체를 만듭니다.
*   `parser.add_argument(...)`: 프로그램이 받아들일 수 있는 특정 인수를 정의합니다.
    *   `"repo_url"`: 이것은 *위치* 인수입니다 – 필수이며 `-o`와 같은 플래그가 필요 없습니다.
    *   `"-o", "--output"`: 이것은 *선택적* 인수입니다. `-o` 또는 `--output` 둘 다 사용할 수 있습니다. 제공하지 않으면 `default` 값("output")을 가집니다.
    *   `nargs="+`는 `--include` 또는 `--exclude` 뒤에 여러 패턴을 나열할 수 있음을 의미합니다.

## 우리의 사용 사례 해결하기

우리의 목표를 기억하시나요? 로컬 폴더 `my_awesome_project`에 대한 튜토리얼을 생성하고 `my_tutorial`에 저장하는 것이었습니다. 방금 배운 인수를 사용하여 명령줄을 열고 튜토리얼 생성기 프로젝트가 있는 디렉토리로 이동한 다음 다음과 같이 입력합니다:

```bash
python main.py ./my_awesome_project -o ./my_tutorial
```

이 명령을 분석해 봅시다:

*   `python main.py`: 컴퓨터에게 Python을 사용하여 `main.py` 스크립트를 실행하라고 지시합니다.
*   `./my_awesome_project`: 필수 `repo_url` 인수의 값입니다. 로컬 경로를 제공하고 있습니다.
*   `-o ./my_tutorial`: `-o` 플래그( `--output`의 축약형)를 사용하여 출력이 현재 위치의 `my_tutorial`이라는 디렉토리로 가야 함을 지정합니다.

이것을 실행하면 `main.py` 스크립트가 시작됩니다!

## 다음엔 무슨 일이 일어날까요? 내부 동작 살펴보기

명령을 실행하여 "시작" 버튼을 눌렀습니다. `main.py`는 여러분의 지침으로 무엇을 할까요?

1.  **인수 파싱:** 앞에서 주석 처리했던 `args = parser.parse_args()`를 사용하여 여러분이 제공한 인수 (`./my_awesome_project`와 `./my_tutorial`)를 읽습니다.
2.  **설정 저장:** 모든 설정 세부 정보(여러분의 인수와 파일 필터처럼 지정하지 않은 것들에 대한 일부 기본값 포함)를 `shared`라고 자주 불리는 Python 딕셔너리에 모읍니다. 이 딕셔너리는 조립 라인의 다른 부분들이 설정을 읽고 결과를 저장할 수 있는 중앙 게시판처럼 작동합니다.

    ```python
    # --- 파일: main.py ---

    # ... (인수 파싱이 여기서 발생) ...
    # args = parser.parse_args()

    # 입력을 사용하여 shared 딕셔너리 초기화
    shared = {
        "repo_url": args.repo_url, # 값은 './my_awesome_project'
        "project_name": args.name, # -n을 제공하지 않았으므로 지금은 None
        "github_token": github_token, # 제공되지 않았다면 None일 수 있음
        "output_dir": args.output, # 값은 './my_tutorial'

        # -i 또는 -e가 사용되지 않은 경우 기본 패턴
        "include_patterns": set(args.include) if args.include else DEFAULT_INCLUDE_PATTERNS,
        "exclude_patterns": set(args.exclude) if args.exclude else DEFAULT_EXCLUDE_PATTERNS,
        # ... 다른 공유 데이터 초기화됨 ...
    }
    print(f"{args.repo_url}에 대한 튜토리얼 생성을 시작합니다.")
    ```

    이 `shared` 딕셔너리는 매우 중요합니다. 전체 튜토리얼 생성 과정 동안 지침과 데이터를 전달합니다.

3.  **워크플로우 생성:** `flow.py`에서 가져온 `create_tutorial_flow` 함수를 호출합니다. 이 함수는 튜토리얼을 생성하는 데 필요한 실제 단계 순서(조립 라인)를 구축합니다. 이는 [5장: 워크플로우 파이프라인 (PocketFlow)](05_workflow_pipeline__pocketflow_.md)에서 더 자세히 살펴볼 것입니다.

    ```python
    # --- 파일: main.py ---
    from flow import create_tutorial_flow # 함수 임포트

    # ... (인수 파싱 및 shared 딕셔너리 생성) ...

    # 플로우 인스턴스 생성
    tutorial_flow = create_tutorial_flow(shared)
    ```

4.  **워크플로우 실행:** 마지막으로, 모든 설정이 포함된 `shared` 딕셔너리를 전달하여 워크플로우에 처리를 시작하도록 지시합니다.

    ```python
    # --- 파일: main.py ---

    # ... (이전 단계들) ...

    # 플로우 실행
    tutorial_flow.run(shared)
    # 이제 조립 라인이 작동하기 시작합니다!
    ```

스크립트를 실행할 때 구성 요소가 어떻게 상호 작용하는지 간략하게 보여주는 다이어그램입니다:

```mermaid
sequenceDiagram
    participant U as 사용자
    participant M as main.py
    participant F as flow.py
    participant P as PocketFlow (워크플로우 엔진)

    U->>M: `python main.py ./my_proj -o ./tut` 실행
    M->>M: 인수 파싱 (`repo_url`, `output` 등)
    M->>M: 설정으로 `shared` 딕셔너리 생성
    M->>F: `create_tutorial_flow(shared)` 호출
    F->>P: 단계 순서 정의 (노드들)
    F-->>M: 설정된 워크플로우 (Flow 객체) 반환
    M->>P: `flow.run(shared)` 호출
    Note right of P: 워크플로우가 단계들을 실행:<br/>1. 코드 가져오기<br/>2. 분석하기<br/>3. ... 등등 ...<br/>(`shared` 딕셔너리 사용/업데이트)
    P-->>M: 실행 완료
```

이 `flow.run(shared)` 호출은 코드 가져오기([4장: 코드베이스 크롤링](04_codebase_crawling.md)), 언어 모델을 사용한 분석([3장: LLM 분석 엔진](03_llm_analysis_engine.md)), 챕터 구조 파악([2장: 튜토리얼 생성](02_tutorial_generation.md)), 그리고 마지막으로 튜토리얼 파일 작성까지 모든 일련의 이벤트를 시작합니다.

## 결론

이제 `main.py` 스크립트를 사용하여 튜토리얼 생성기를 시작하는 방법과 `repo_url`(코드 위치용) 및 `--output`(결과용)과 같은 명령줄 인수를 사용하여 동작을 설정하는 방법을 배웠습니다. 또한 이러한 설정이 어떻게 `shared` 딕셔너리에 수집되어 주 워크플로우를 시작하는 데 사용되는지 확인했습니다.

이제 "제어판"을 작동하고 "시작" 버튼을 누르는 방법을 알게 되었습니다!

다음으로, 워크플로우가 수행하는 첫 번째 주요 작업 중 하나인 코드의 고수준 개념을 파악하여 튜토리얼 챕터가 무엇에 관한 것이어야 하는지 결정하는 과정에 대해 자세히 알아보겠습니다. [2장: 튜토리얼 생성](02_tutorial_generation.md)으로 넘어가 봅시다.

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)