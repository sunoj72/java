# Chapter 5: Workflow Pipeline (PocketFlow)

```markdown
# 5장: 워크플로우 파이프라인 (PocketFlow)

다시 오신 것을 환영합니다! 이전 장들에서는 튜토리얼 생성기의 흥미로운 부분들을 살펴보았습니다:

*   [1장: 설정 및 실행](01_configuration___execution.md): 프로세스를 시작하고 명령을 내리는 방법.
*   [2장: 튜토리얼 생성](02_tutorial_generation.md): 튜토리얼의 구조와 내용을 계획하고 작성하는 방법.
*   [3장: LLM 분석 엔진](03_llm_analysis_engine.md): 코드를 이해하는 "전문가 컨설턴트"(LLM).
*   [4장: 코드베이스 크롤링](04_codebase_crawling.md): 소스 코드 파일을 가져오는 "사서".

파일 가져오기, 개념 식별, 관계 분석, 챕터 순서 정하기, 내용 작성, 최종 결과물 결합과 같은 개별 작업들을 보았습니다. 하지만 시스템은 어떻게 이 작업들이 *올바른 순서로* 일어나도록 보장할까요? 전체 과정을 관리하고, 한 단계의 출력이 다음 단계의 입력이 되도록 만드는 것은 무엇일까요?

바로 여기서 **워크플로우 파이프라인**이 등장합니다! 이 파이프라인은 **PocketFlow**라는 작은 라이브러리로 구동됩니다.

## 문제: 복잡한 프로세스 관리하기

자동차를 조립한다고 상상해보세요. 차대, 엔진, 도색, 좌석 설치 등 다양한 작업 스테이션이 있습니다. 차대가 만들어지기 전에 차를 도색할 수 없고, 도색이 끝나기 전에 좌석을 설치할 수 없습니다. 순서가 중요하죠!

우리의 튜토리얼 생성기도 비슷합니다. 특정 순서로 여러 단계를 수행해야 합니다:

1.  코드 **가져오기** (코드가 없으면 분석할 수 없어요!).
2.  주요 개념 **식별하기** (개념이 있어야 관계를 분석할 수 있죠).
3.  개념들이 어떻게 관련되는지 **분석하기** (관계가 있어야 챕터 순서를 정할 수 있어요).
4.  챕터 **순서 정하기**.
5.  각 챕터의 내용 **작성하기**.
6.  모든 것을 최종 튜토리얼 파일로 **결합하기**.

이 단계들을 수동으로 하거나 순서 없이 수행하면 오류가 발생하거나 말이 안 되는 결과가 나올 것입니다. 이 조립 라인을 감독할 관리자가 필요합니다.

## 우리의 해결책: 조립 라인 관리자 (PocketFlow)

**PocketFlow**를 튜토리얼 공장 조립 라인의 관리자라고 생각해보세요. 이 관리자의 역할은 다음과 같습니다:

1.  **순서 알기:** 작업(여기서는 **노드(Node)**라고 부릅니다)이 수행되어야 하는 정확한 순서를 이해합니다.
2.  **흐름 지시하기:** 코드베이스 정보가 한 스테이션(노드)에서 다음 스테이션으로 올바르게 이동하도록 보장합니다.
3.  **실행 관리하기:** 조립 라인을 시작하고 각 스테이션이 다음 스테이션으로 작업을 넘기기 전에 제 역할을 다하도록 합니다.

PocketFlow는 이러한 작업 순서를 정의하고 원활하게 실행하는 간단한 방법을 제공합니다.

## 조립 라인 정의하기: `flow.py`

PocketFlow에게 작업의 올바른 순서를 어떻게 알려줄까요? 특정 파일인 `flow.py`에서 `create_tutorial_flow`라는 함수를 사용하여 정의합니다. 단순화된 버전을 살펴봅시다:

```python
# --- flow.py 단순화 버전 ---
from pocketflow import Flow
# '노드' 클래스(작업 스테이션) 임포트
from nodes import (
    FetchRepo, FetchLocal, IdentifyAbstractions,
    AnalyzeRelationships, OrderChapters, WriteChapters, CombineTutorial
)

def create_tutorial_flow(shared):
    """코드베이스 튜토리얼 생성 흐름을 만들고 반환합니다."""

    # 1. 입력 URL 기반으로 어떤 '가져오기' 노드를 사용할지 결정
    if shared["repo_url"].startswith("http"):
        fetch_node = FetchRepo() # GitHub 가져오기 노드 사용
    else:
        fetch_node = FetchLocal() # 로컬 폴더 가져오기 노드 사용

    # 2. 다른 모든 노드(작업 스테이션)의 인스턴스 생성
    # (max_retries는 단계 실패 시 PocketFlow가 재시도하도록 지시)
    identify_node = IdentifyAbstractions(max_retries=3)
    analyze_node = AnalyzeRelationships(max_retries=3)
    order_node = OrderChapters(max_retries=3)
    write_node = WriteChapters(max_retries=3)
    combine_node = CombineTutorial()

    # 3. '>>' 연산자를 사용하여 순서 정의
    # 'fetch_node의 출력이 identify_node로 간다' 등을 의미
    fetch_node >> identify_node >> analyze_node >> order_node \
               >> write_node >> combine_node

    # 4. fetch_node로 시작하는 최종 Flow 객체 생성
    tutorial_flow = Flow(start=fetch_node)

    return tutorial_flow
```

**설명:**

1.  **Fetcher 선택:** `shared` 딕셔너리(1장에서 왔죠)의 `repo_url`이 웹 URL인지 로컬 경로인지에 따라 시작점으로 `FetchRepo` 노드를 사용할지 `FetchLocal` 노드를 사용할지 결정합니다.
2.  **노드 인스턴스화:** 프로세스의 각 단계(노드)에 대한 객체를 만듭니다. 이는 조립 라인의 각 작업 스테이션을 설정하는 것과 같습니다. 이 노드들 안에 무엇이 있는지는 [6장: 처리 노드](06_processing_nodes.md)에서 더 자세히 배울 것입니다.
3.  **노드 연결 (`>>`):** 이것이 핵심 부분입니다! `>>` 연산자는 PocketFlow에게 순서를 알려줍니다. `fetch_node >> identify_node`는 "`fetch_node`가 끝나면 `identify_node`를 실행하라"는 의미입니다. 이들을 연결하여 전체 순서를 정의합니다: 가져오기 -> 식별 -> 분석 -> 순서 정하기 -> 작성 -> 결합.
4.  **Flow 생성:** 마지막으로, `Flow` 객체를 생성하여 PocketFlow에게 `fetch_node`가 가장 첫 번째 단계임을 알려줍니다.

이 `create_tutorial_flow` 함수는 본질적으로 우리 조립 라인의 청사진을 만듭니다.

## 조립 라인 시작하기: `main.py`

[1장: 설정 및 실행](01_configuration___execution.md)에서 인수를 파싱하고 `shared` 딕셔너리를 만든 후, `main.py`가 했던 일을 기억하시나요?

```python
# --- main.py의 일부 ---
from flow import create_tutorial_flow # 청사진 함수 임포트

# ... (여기서 인수 파싱 및 shared 딕셔너리 생성) ...

# 청사진을 사용하여 flow 인스턴스 생성
tutorial_flow = create_tutorial_flow(shared)

# flow 실행 - 조립 라인 시작!
print("튜토리얼 생성 워크플로우를 시작합니다...")
tutorial_flow.run(shared)
print("워크플로우가 완료되었습니다.")
```

1.  `create_tutorial_flow(shared)`를 호출하여 설정된 조립 라인 청사진(`Flow` 객체)을 얻습니다.
2.  그런 다음 `tutorial_flow.run(shared)`가 호출됩니다. 이것은 조립 라인의 큰 "시작" 버튼을 누르는 것과 같습니다!

## PocketFlow가 쇼를 진행하는 방법

`tutorial_flow.run(shared)`가 호출되면 PocketFlow가 제어를 받습니다:

1.  **시작 노드:** `Flow` 객체에 정의된 `start` 노드(`FetchRepo` 또는 `FetchLocal`)를 찾습니다.
2.  **노드 실행:** 첫 번째 노드를 실행합니다. 6장에서 보게 되겠지만, 각 노드에는 `prep`( `shared`에서 입력 준비), `exec`(실제 작업 수행), `post`( `shared`에 결과 저장)와 같은 단계가 있습니다. PocketFlow는 이러한 메서드를 호출하는 것을 관리합니다.
3.  **`shared`를 통한 데이터 전달:** 중요한 `shared` 딕셔너리가 각 노드에 전달됩니다. `FetchLocal`이 끝나면 파일 목록을 `shared["files"]`에 넣습니다.
4.  **다음 노드:** PocketFlow는 연결(`>>`)을 봅니다. 가져오기 노드 다음에 `IdentifyAbstractions`가 오는 것을 확인합니다.
5.  **다음 노드 실행:** `IdentifyAbstractions`를 실행합니다. 이 노드는 `shared["files"]`를 읽고, LLM 분석([3장](03_llm_analysis_engine.md))을 수행하고, 결과를 `shared["abstractions"]`에 저장합니다.
6.  **반복:** PocketFlow는 `>>` 연결을 계속 따라가며 `AnalyzeRelationships`( `shared["abstractions"]` 사용, `shared["relationships"]` 저장), 그 다음 `OrderChapters`, `WriteChapters`, 마지막으로 `CombineTutorial`을 실행하며, 매번 `shared` 딕셔너리를 사용하고 업데이트합니다.
7.  **마침:** 마지막 노드(`CombineTutorial`)가 끝나면 `run()` 호출이 완료되고, `main.py`는 "워크플로우가 완료되었습니다."를 출력합니다.

PocketFlow가 순서를 실행하는 방식을 보여주는 다이어그램입니다:

```mermaid
sequenceDiagram
    participant Main as main.py
    participant PF as PocketFlow 엔진
    participant Fetch as Fetch 노드
    participant Identify as Identify 노드
    participant Analyze as Analyze 노드
    participant Shared as shared 딕셔너리

    Main->>PF: flow.run(shared) 호출
    PF->>Fetch: 노드 1 실행 (Fetch)
    Note right of Fetch: shared에서 설정 읽기<br/>파일 가져오기
    Fetch->>Shared: shared["files"]에 결과 쓰기
    Fetch-->>PF: 노드 1 완료
    PF->>Identify: 노드 2 실행 (Identify)
    Note right of Identify: shared["files"] 읽기<br/>LLM 호출
    Identify->>Shared: shared["abstractions"]에 결과 쓰기
    Identify-->>PF: 노드 2 완료
    PF->>Analyze: 노드 3 실행 (Analyze)
    Note right of Analyze: shared["abstractions"] 읽기<br/>LLM 호출
    Analyze->>Shared: shared["relationships"]에 결과 쓰기
    Analyze-->>PF: 노드 3 완료
    Note over PF: ... Order, Write, Combine에 대해 계속 ...
    PF-->>Main: 워크플로우 완료
```

PocketFlow는 지휘자처럼 행동하여 각 파트가 올바른 시간에 연주하도록 하고, 정보가 `shared` 딕셔너리를 통해 올바르게 전달되도록 합니다. 또한 노드가 실패할 경우 재시도하는 것과 같은 일도 처리합니다 (앞서 본 `max_retries=3` 덕분이죠).

## 결론

PocketFlow가 관리하는 워크플로우 파이프라인은 튜토리얼 생성기의 중추입니다. 복잡한 작업 순서를 조정하는 문제를 조립 라인 관리자처럼 해결합니다. `flow.py`에서 단계(노드)의 순서와 연결(`>>`)을 정의하고, `main.py`는 `flow.run(shared)`를 사용하여 프로세스를 시작합니다. PocketFlow는 각 노드가 올바른 순서로 실행되도록 보장하며, 중앙 `shared` 딕셔너리를 사용하여 노드 간에 데이터를 전달합니다.

이러한 체계적인 접근 방식 덕분에 코드 가져오기, 분석, 튜토리얼 생성이라는 복잡한 과정이 관리 가능하고 신뢰할 수 있게 됩니다.

이제 *전체* 흐름이 어떻게 관리되는지 이해했으니, 조립 라인의 개별 작업 스테이션을 자세히 살펴보겠습니다. 각 노드 안에서는 정확히 어떤 일이 일어날까요?

[6장: 처리 노드](06_processing_nodes.md)로 넘어가서 알아봅시다!
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)