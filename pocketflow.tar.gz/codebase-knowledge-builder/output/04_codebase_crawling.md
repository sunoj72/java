# Chapter 4: Codebase Crawling

```markdown
# 4장: 코드베이스 크롤링

다시 오신 것을 환영합니다! [3장: LLM 분석 엔진](03_llm_analysis_engine.md)에서는 우리 시스템의 "두뇌", 즉 코드의 핵심 개념과 관계를 찾아내는 LLM에 대해 알아보았습니다. 마치 프로젝트 문서를 읽고 통찰력을 제공하는 전문가 컨설턴트와 같았죠.

그런데 잠깐... 그 "프로젝트 문서"(소스 코드 파일)는 실제로 어디서 오는 걸까요? LLM이 무언가를 분석하려면, 먼저 코드를 *가져와야* 합니다! 이것이 바로 **코드베이스 크롤러**가 하는 일입니다.

## 문제: 올바른 코드 가져오기

여러분이 찾은 멋진 프로젝트를 우리 튜토리얼 생성기로 설명하고 싶다고 상상해 보세요. 어쩌면 GitHub에 온라인으로 호스팅되어 있거나, 여러분의 컴퓨터에 다운로드한 프로젝트일 수도 있습니다. 생성기는 그 코드를 어디서 찾아야 할지 어떻게 알 수 있을까요? 그리고 만약 프로젝트 폴더에 테스트 스크립트, 빌드 결과물, 또는 거대한 데이터 파일처럼 튜토리얼에 포함하고 싶지 않은 추가 파일들이 많이 있다면 어떨까요? 우리는 튜토리얼 생성에 *정말로 필요한* 소스 코드만 가져올 방법이 필요합니다.

## 우리의 해결책: 디지털 사서 (코드베이스 크롤러)

코드베이스 크롤러를 매우 효율적인 **사서**라고 생각해보세요. 이 사서의 임무는 분석을 위해 책(코드 파일)을 가져오는 것입니다. 이 사서는 꽤 다재다능합니다:

1.  **온라인 디지털 도서관 (GitHub):** GitHub URL을 제공하면, 사서는 온라인으로 가서 특정 저장소를 찾고 파일을 다운로드하는 방법을 알고 있습니다.
2.  **지역 도서관 서가 (여러분의 컴퓨터):** 컴퓨터에 있는 폴더 경로를 제공하면, 사서는 그 서가로 걸어가서 파일을 가져올 수 있습니다.

하지만 이 사서는 똑똑하기도 합니다! 여러분은 **특별 지침**을 줄 수 있습니다:

*   **"파이썬 책만 가져다 주세요!"** (포함 패턴, 예: `*.py`)
*   **"'tests'나 'docs' 섹션에 있는 것은 무시하세요."** (제외 패턴, 예: `tests/*`, `docs/*`)
*   **"100페이지보다 두꺼운 것은 가져오지 마세요!"** (최대 파일 크기 제한)

코드베이스 크롤러는 이러한 지침을 정확하게 따르며, 튜토리얼 생성에 정말로 필요한 소스 코드 파일만 수집하여 시간과 자원을 절약합니다.

## 사서에게 무엇을 하라고 어떻게 알려줄까요?

[1장: 설정 및 실행](01_configuration___execution.md)을 기억하시나요? 우리는 생성기를 시작하기 위해 명령줄 인수를 사용했습니다. 그 인수 중 일부가 바로 우리 사서를 위한 지침이었습니다!

다시 한번 살펴봅시다:

```bash
# 예제 1: GitHub에서 가져오기
python main.py https://github.com/사용자/프로젝트 -o ./내_튜토리얼

# 예제 2: 로컬 폴더에서 가져오기
python main.py ./내_멋진_프로젝트 -o ./내_튜토리얼

# 예제 3: 필터를 사용하여 가져오기 (로컬 폴더)
python main.py ./내_멋진_프로젝트 -o ./내_튜토리얼 \
    -i "*.py" "*.js" \
    -e "tests/*" "build/*" \
    -s 50000
```

*   **첫 번째 인수 (`repo_url`):** 사서에게 *어디를* 봐야 할지 알려줍니다. `https://github.com/...` URL이거나 `./내_멋진_프로젝트`와 같은 로컬 경로일 수 있습니다.
*   **`--include` (`-i`):** 사서에게 이 패턴과 일치하는 파일*만* 가져오라고 지시합니다 (예: 파이썬 파일의 경우 `*.py`).
*   **`--exclude` (`-e`):** 사서에게 이 패턴과 일치하는 파일이나 폴더를 *무시*하라고 지시합니다.
*   **`--max-size` (`-s`):** 사서에게 이 크기(바이트 단위)보다 큰 파일을 건너뛰라고 지시합니다. 50000 바이트는 약 50KB입니다.

`main.py`를 실행하면, 이 인수들을 읽어서 우리가 이야기했던 `shared` 딕셔너리에 저장합니다.

## 내부 동작: 크롤링 과정

자, 여러분은 명령줄을 통해 지침을 주었습니다. 시스템 내부에서는 어떤 일이 일어날까요?

1.  **결정 시간:** 워크플로우([5장: 워크플로우 파이프라인 (PocketFlow)](05_workflow_pipeline__pocketflow_.md)에서 더 자세히 다룰 예정)는 여러분이 `shared` 딕셔너리에 제공한 `repo_url`을 살펴봅니다.
    *   GitHub URL처럼 보이면, `FetchRepo` 노드(GitHub 전문가)를 사용하기로 결정합니다.
    *   로컬 경로처럼 보이면, `FetchLocal` 노드(로컬 폴더 전문가)를 사용하기로 결정합니다.

2.  **파일 가져오기:** 로컬 폴더(`FetchLocal`)의 경로를 따라가 봅시다:
    *   **준비 (`prep`):** `FetchLocal` 노드는 `shared` 딕셔너리에서 `repo_url`, `include_patterns`, `exclude_patterns`, `max_file_size`를 읽습니다.
    *   **실행 (`exec`):** 경로와 필터 규칙을 전달하면서 `crawl_local_files`라는 헬퍼 유틸리티 함수를 호출합니다.
    *   **크롤링 (`crawl_local_files`):** 이 유틸리티 함수는 사서가 실제로 서가를 돌아다니는 것처럼 행동합니다:
        *   파이썬의 `os.walk`를 사용하여 지정된 디렉토리와 그 하위 디렉토리의 모든 파일을 살펴봅니다.
        *   각 파일에 대해 다음을 확인합니다:
            *   파일 이름이 `include_patterns` 중 하나와 일치하는가? (`fnmatch` 사용)
            *   파일 경로가 `exclude_patterns` 중 하나와 일치하는가? (`fnmatch` 사용)
            *   파일 크기(`os.path.getsize`)가 `max_file_size`보다 작은가?
        *   파일이 모든 검사를 통과하면, 사서는 파일을 열고 내용을 읽어서 파일의 상대 경로와 내용을 저장합니다. 검사를 통과하지 못한 파일은 건너뜁니다.
    *   **결과 저장 (`post`):** `FetchLocal` 노드는 유틸리티로부터 (경로, 내용) 쌍의 리스트를 돌려받습니다. 그런 다음 이 리스트를 `"files"`라는 키 아래 `shared` 딕셔너리에 저장합니다.

다음은 로컬 파일 가져오기 과정을 단순화한 다이어그램입니다:

```mermaid
sequenceDiagram
    participant M as main.py
    participant WF as 워크플로우 엔진
    participant FL as FetchLocal 노드
    participant CLF as crawl_local_files 유틸리티
    participant Shared as shared 딕셔너리

    M->>M: 인수 파싱 (repo_url=./proj, include 등)
    M->>Shared: shared 딕셔너리에 인수 저장
    M->>WF: flow.run(shared) 시작
    WF->>FL: FetchLocal 노드 실행
    FL->>Shared: shared에서 repo_url, 필터 읽기
    FL->>CLF: crawl_local_files(경로, 필터) 호출
    CLF->>CLF: 디렉토리 탐색 (os.walk)
    loop 각 파일에 대해
        CLF->>CLF: 포함 패턴 확인 (fnmatch)
        CLF->>CLF: 제외 패턴 확인 (fnmatch)
        CLF->>CLF: 파일 크기 확인 (os.path.getsize)
        alt 파일 검사 통과
            CLF->>CLF: 파일 내용 읽기
            CLF->>CLF: 결과에 (경로, 내용) 추가
        else 파일 검사 실패
            CLF->>CLF: 파일 건너뛰기
        end
    end
    CLF-->>FL: (경로, 내용) 리스트 반환
    FL->>Shared: shared["files"]에 결과 저장
    FL-->>WF: 노드 실행 완료
```

`FetchRepo`와 `crawl_github_files`의 과정도 비슷하지만, 로컬 디렉토리를 탐색하는 대신 GitHub API를 사용하여 파일 목록을 가져오고 내용을 다운로드하며 동일한 필터링 로직을 적용합니다.

## 코드 살짝 보기

로컬 크롤링을 위한 주요 구성 요소의 단순화된 버전을 살펴봅시다:

**1. `FetchLocal` 노드 (`nodes.py`에서)**

이 노드는 로컬 파일 가져오기 과정을 지휘합니다.

```python
# --- nodes.py 단순화 버전 ---
import os
from pocketflow import Node
from utils.crawl_local_files import crawl_local_files # 유틸리티 함수

class FetchLocal(Node):
    # 단계 1: 준비 - shared 딕셔너리에서 지침 가져오기
    def prep(self, shared):
        repo_url = shared["repo_url"] # 어디를 볼지
        include_patterns = shared["include_patterns"] # 무엇을 포함할지
        exclude_patterns = shared["exclude_patterns"] # 무엇을 제외할지
        max_file_size = shared["max_file_size"]       # 크기 제한

        # 실행 단계에 필요한 정보 반환
        return {
            "repo_url": repo_url,
            "include_patterns": include_patterns,
            "exclude_patterns": exclude_patterns,
            "max_file_size": max_file_size,
            "use_relative_paths": True # 경로를 깔끔하게 유지
        }

    # 단계 2: 실행 - 사서 유틸리티 호출
    def exec(self, prep_res):
        print(f"로컬 디렉토리 크롤링 중: {prep_res['repo_url']}...")
        # 준비된 인수로 헬퍼 함수 호출
        result = crawl_local_files(
            repo_url=prep_res["repo_url"],
            include_patterns=prep_res["include_patterns"],
            exclude_patterns=prep_res["exclude_patterns"],
            max_file_size=prep_res["max_file_size"],
            use_relative_paths=prep_res["use_relative_paths"]
        )
        # 파일 리스트 가져오기: [(경로1, 내용1), (경로2, 내용2), ...]
        files_list = list(result.get("files", {}).items())
        print(f"{len(files_list)}개 파일 가져옴.")
        return files_list # 가져온 파일 리스트 반환

    # 단계 3: 후처리 - 결과 저장
    def post(self, shared, prep_res, exec_res):
        # (경로, 내용) 튜플 리스트를 shared 딕셔너리에 저장
        shared["files"] = exec_res
```

*   `prep`: 초기에 제공된 설정(`repo_url`, 필터)을 `shared` 딕셔너리에서 읽습니다(1장).
*   `exec`: 설정을 사용하여 실제 크롤링 함수 `crawl_local_files`를 호출합니다.
*   `post`: `exec`의 결과(파일 리스트)를 가져와 `"files"` 키 아래 `shared` 딕셔너리에 다시 저장합니다.

**2. `crawl_local_files` 유틸리티 (`utils/crawl_local_files.py`에서)**

이 함수가 실제로 디렉토리를 탐색하고 필터링하는 작업을 수행합니다.

```python
# --- utils/crawl_local_files.py 단순화 버전 ---
import os
import fnmatch # 패턴 매칭용 (*.py, tests/*)

def crawl_local_files(repo_url, include_patterns, exclude_patterns, max_file_size, use_relative_paths):
    files = {} # 경로 -> 내용 을 저장할 딕셔너리
    skipped_files = []

    # 포함/제외 패턴 확인 함수
    def should_include_file(rel_path, filename):
        # 포함 패턴 확인 (예: *.py)
        include_ok = not include_patterns or \
                     any(fnmatch.fnmatch(filename, pattern) for pattern in include_patterns)
        if not include_ok: return False

        # 제외 패턴 확인 (예: tests/*)
        exclude_ok = not exclude_patterns or \
                     not any(fnmatch.fnmatch(rel_path, pattern) for pattern in exclude_patterns)
        return exclude_ok

    # 디렉토리 탐색
    for root, _, filenames in os.walk(repo_url):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            # 시작 디렉토리 기준 상대 경로 얻기
            rel_path = os.path.relpath(file_path, repo_url)

            # 필터 적용
            if not should_include_file(rel_path, filename):
                # print(f"{rel_path} 건너뛰기: 패턴에 의해 필터링됨")
                continue

            try:
                file_size = os.path.getsize(file_path)
                if file_size > max_file_size:
                    # print(f"{rel_path} 건너뛰기: 너무 큼 ({file_size} 바이트)")
                    skipped_files.append((rel_path, file_size))
                    continue

                # 모든 검사를 통과하면 파일 내용 읽기
                with open(file_path, "r", encoding="utf-8") as f:
                    files[rel_path] = f.read()
                    # print(f"읽음: {rel_path}")

            except Exception as e:
                print(f"{rel_path} 읽기 오류: {e}")

    # 파일 딕셔너리와 일부 통계 반환
    return {"files": files, "stats": {"skipped_count": len(skipped_files)}}
```

*   `os.walk`: 모든 디렉토리와 파일을 순회하는 표준 파이썬 함수입니다.
*   `fnmatch.fnmatch`: 파일 이름이나 경로가 와일드카드 패턴(예: `*.py` 또는 `tests/*`)과 일치하는지 확인하는 데 사용됩니다.
*   `os.path.getsize`: 파일 크기를 바이트 단위로 확인합니다.
*   `open(...)`: 필터를 통과한 파일의 내용을 읽습니다.

결과는 `files` 딕셔너리이며, 키는 상대 경로(예: `src/main.py`)이고 값은 해당 파일의 텍스트 내용입니다. `FetchLocal` 노드는 이를 `shared["files"]`에 저장되는 튜플 리스트로 변환합니다.

## 결론

이제 디지털 사서인 코드베이스 크롤러에 대해 배웠습니다! GitHub에서든 로컬 컴퓨터에서든 소스 코드를 가져오는 중요한 첫 단계를 담당합니다. `repo_url`을 사용하여 어디를 봐야 할지 알고, 포함/제외 패턴과 크기 제한(명령줄 인수를 통해 제공)을 적용하여 관련 파일만 검색하는 방법을 보았습니다.

이 단계의 출력은 파일 경로와 내용의 깔끔한 리스트이며, `shared["files"]`에 저장되어 분석([3장: LLM 분석 엔진](03_llm_analysis_engine.md)) 및 튜토리얼 작성([2장: 튜토리얼 생성](02_tutorial_generation.md))과 같은 다음 단계를 위해 준비됩니다.

하지만 이 모든 단계(가져오기, 분석, 작성)는 어떻게 연결되고 관리될까요? 시스템은 어떻게 올바른 순서로 실행되도록 보장할까요? 이는 다음 장에서 살펴볼 **워크플로우 파이프라인 (PocketFlow)** 에 의해 조정됩니다!

[5장: 워크플로우 파이프라인 (PocketFlow)](05_workflow_pipeline__pocketflow_.md)으로 넘어가 봅시다.

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)