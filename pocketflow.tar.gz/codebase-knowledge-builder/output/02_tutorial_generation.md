# Chapter 2: Tutorial Generation

```markdown
# 2장: 튜토리얼 생성

다시 오신 것을 환영합니다! [1장: 설정 및 실행](01_configuration___execution.md)에서는 `main.py`와 명령줄 인수를 사용하여 튜토리얼 생성기를 시작하는 방법을 배웠습니다. 여러분의 지침(코드 위치, 출력 디렉토리 등)이 어떻게 중앙 `shared` 딕셔너리에 수집되고, 메인 워크플로우가 어떻게 시작되는지 보았습니다.

하지만 엔진을 시동하는 것은 첫 단계일 뿐입니다. 원시 코드를 가져왔고 ([4장: 코드베이스 크롤링](04_codebase_crawling.md)에서 *어떻게* 하는지 다룰 것입니다), 그 내용이 `shared` 딕셔너리에서 기다리고 있습니다. 이제 무엇을 해야 할까요? 코드 파일 모음을 어떻게 체계적이고 이해하기 쉬운 튜토리얼(챕터, 설명, 다이어그램 포함)로 변환할 수 있을까요?

바로 여기서 **튜토리얼 생성** 단계가 등장합니다!

## 목표: 원시 분석에서 완성된 튜토리얼까지

복잡한 기계(코드베이스)를 연구하기 위해 전문 컨설턴트([3장: LLM 분석 엔진](03_llm_analysis_engine.md)에서 다룰 내용)를 고용했다고 상상해보세요. 컨설턴트는 기계가 어떻게 작동하는지에 대한 기술 노트, 다이어그램, 관찰 결과 더미를 제공합니다. 이 노트들은 가치가 있지만, 밀도가 높고 정리가 되어 있지 않습니다.

**튜토리얼 생성** 과정은 숙련된 **기술 작가**를 고용하는 것과 같습니다. 그들의 임무는 전문가의 원시 노트와 다이어그램을 가져와 이해하고, 논리적으로 구성하고, 기계를 처음 보는 초보자를 위해 명확하고 단계별 지침서(우리의 튜토리얼)를 작성하는 것입니다.

이 단계는 분석 엔진이 생성한 통찰력을 가져와 사용자 친화적인 여러 챕터의 마크다운 튜토리얼로 구성합니다. 주요 주제를 파악하고, 설명하기 가장 좋은 순서를 결정하고, 각 챕터의 내용을 작성하고, 다이어그램을 만들고, 마지막으로 모든 것을 색인이 있는 완성된 제품으로 조립합니다.

## 단계: 조각조각 튜토리얼 만들기

이 "기술 작가"는 모든 것을 한 번에 하지 않습니다. 일련의 단계를 따르며, 각 단계는 워크플로우 시스템에서 `Node`라고 불리는 특정 구성 요소에 의해 처리됩니다. 여정을 따라가 봅시다:

1.  **핵심 아이디어 식별 (`IdentifyAbstractions` 노드):**
    *   **문제:** 어디서부터 시작해야 할까요? 초보자가 알아야 할 코드베이스의 주요 개념이나 부분은 무엇일까요?
    *   **해결책:** 이 노드는 LLM(우리의 전문 컨설턴트)에게 모든 코드 파일을 살펴보고 가장 중요한 "추상화"(핵심 아이디어나 구성 요소) 5-10개를 식별하도록 요청합니다. 각각에 대해 이름, 간단한 설명(비유 포함!), 관련 코드 파일 목록을 요청합니다.
    *   **비유:** 기술 작가는 전문가의 노트를 훑어보며 반복적으로 등장하는 주요 주제(예: "엔진 시동 순서", "연료 분사 시스템", "냉각 장치")를 찾습니다.
    *   **결과:** 튜토리얼 챕터가 될 핵심 개념 목록입니다. 이 목록은 `shared` 딕셔너리에 `"abstractions"`라는 키 아래 저장됩니다.

2.  **아이디어 연결 방식 이해 (`AnalyzeRelationships` 노드):**
    *   **문제:** 주제 목록은 있는데, 이것들이 서로 어떻게 관련되어 있을까요? "연료 분사 시스템"이 "엔진 시동 순서"를 *사용*하나요?
    *   **해결책:** 이 노드는 추상화 목록을 가져와 LLM에게 그것들이 어떻게 상호 작용하는지 분석하도록 요청합니다. 또한 전체 프로젝트가 무엇을 하는지에 대한 간략하고 높은 수준의 요약을 요청합니다.
    *   **비유:** 기술 작가는 노트의 주제들 사이에 선과 화살표를 그리고 "데이터 전송" 또는 "제어"와 같은 라벨을 추가합니다. 또한 매뉴얼을 위한 짧은 소개글을 작성합니다.
    *   **결과:** 프로젝트 요약 및 연결 관계를 설명하는 목록(예: 추상화 A가 추상화 B를 "관리함"). 이는 `shared["relationships"]`에 저장됩니다.

3.  **읽기 순서 계획 (`OrderChapters` 노드):**
    *   **문제:** 주제와 연결 방식은 알지만, 초보자가 어떤 순서로 읽어야 할까요? 연료 시스템 *전에* 엔진을 설명해야 할까요?
    *   **해결책:** 이 노드는 추상화와 그 관계를 살펴보고 LLM에게 가장 논리적인 교육 순서를 결정하도록 요청합니다. 종종 이는 기초적이거나 사용자에게 직접 보이는 개념부터 시작하여 더 상세하거나 내부적인 개념으로 이동하는 것을 의미합니다.
    *   **비유:** 기술 작가는 사용 설명서의 챕터 순서를 결정합니다. 아마도 "키 돌리기"부터 시작하여 "엔진 내부"로 들어가는 식일 것입니다.
    *   **결과:** 어떤 추상화가 1장, 2장 등이 되어야 하는지를 나타내는 순서 목록입니다. 이 순서(인덱스 목록)는 `shared["chapter_order"]`에 저장됩니다.

4.  **콘텐츠 작성 (`WriteChapters` 노드):**
    *   **문제:** 계획(주제, 순서, 연결)은 세웠습니다. 이제 각 챕터의 실제 텍스트가 필요합니다!
    *   **해결책:** 이 노드는 `chapter_order`를 하나씩 따라갑니다. 각 추상화에 대해 LLM에게 초보자 친화적인 마크다운 챕터를 작성하도록 요청합니다. 이때 추상화 설명, 관련 코드 스니펫, 관계 컨텍스트, 이전/다음 챕터 정보를 사용하여 부드러운 전환을 만듭니다. 이것은 특별한 `BatchNode`로, 각 챕터 작성 작업을 개별적으로 처리한다는 의미입니다.
    *   **비유:** 기술 작가는 앉아서 각 챕터의 텍스트 초안을 작성합니다. 노트, 개요, 다이어그램을 참조하며 개념을 명확하게 설명하고 서로 연결되도록 합니다.
    *   **결과:** 마크다운 문자열 목록으로, 각 문자열은 한 챕터의 전체 내용입니다. 이 목록은 `shared["chapters"]`에 저장됩니다.

5.  **최종 결과물 조립 (`CombineTutorial` 노드):**
    *   **문제:** 개별 챕터 파일들이 작성되었습니다. 이것들을 최종적이고 사용 가능한 튜토리얼로 어떻게 묶을 수 있을까요?
    *   **해결책:** 이 노드는 생성된 모든 챕터 콘텐츠, 프로젝트 요약, 관계 데이터, 챕터 순서를 가져옵니다. 다음을 생성합니다:
        *   `index.md` 파일: 표지 및 목차 역할을 하며, 프로젝트 요약, 추상화 간의 관계를 보여주는 다이어그램(Mermaid 사용!), 각 챕터 파일 링크를 포함합니다.
        *   개별 챕터 파일 (예: `01_configuration___execution.md`, `02_tutorial_generation.md` 등): `WriteChapters`에서 생성된 마크다운 콘텐츠를 1장에서 지정한 출력 디렉토리 내에 적절한 이름의 파일로 저장합니다.
    *   **비유:** 기술 작가는 모든 초안 챕터를 컴파일하고, 목차를 만들고, 소개 요약과 관계 다이어그램을 추가하고, 모든 것을 최종 사용 설명서로 묶어 지정된 폴더에 저장합니다.
    *   **결과:** 깔끔하게 디렉토리에 정리된 완전한 튜토리얼, 바로 읽을 준비 완료! 이 디렉토리 경로는 `shared["final_output_dir"]`에 저장됩니다.

## 내부 동작: 데이터 흐름 방식

이 단계들은 마법이 아닙니다. [5장: 워크플로우 파이프라인 (PocketFlow)](05_workflow_pipeline__pocketflow_.md)에서 설명할 워크플로우 엔진에 의해 조정되는 `nodes.py` 파일 내의 파이썬 코드로 실행됩니다. 핵심은 1장에서 만났던 `shared` 딕셔너리를 사용하여 정보가 어떻게 전달되는가입니다.

튜토리얼 생성의 데이터 흐름을 단순화하여 살펴보겠습니다:

```mermaid
sequenceDiagram
    participant Shared as shared 딕셔너리
    participant Identify as IdentifyAbstractions 노드
    participant Analyze as AnalyzeRelationships 노드
    participant Order as OrderChapters 노드
    participant Write as WriteChapters 노드
    participant Combine as CombineTutorial 노드

    Note over Shared: 'files', 'repo_url', 'output_dir' 등으로 시작
    Shared->>Identify: 'files' 데이터 제공
    Identify->>Identify: LLM에게 추상화 요청
    Identify->>Shared: 'abstractions' 목록 추가
    Shared->>Analyze: 'abstractions' 목록 제공
    Analyze->>Analyze: LLM에게 요약 및 관계 요청
    Analyze->>Shared: 'relationships' 딕셔너리 추가
    Shared->>Order: 'abstractions', 'relationships' 제공
    Order->>Order: LLM에게 챕터 순서 요청
    Order->>Shared: 'chapter_order' 목록 추가
    Shared->>Write: 'chapter_order', 'abstractions', 'files' 등 제공
    loop 순서대로 각 챕터에 대해
        Write->>Write: LLM에게 챕터 내용 작성 요청
    end
    Write->>Shared: 'chapters' 목록 추가 (모든 콘텐츠)
    Shared->>Combine: 'chapters', 'relationships', 'chapter_order' 등 제공
    Combine->>Combine: index.md, 챕터 파일, 다이어그램 생성
    Combine->>Shared: 'final_output_dir' 경로 추가
    Note over Shared: 튜토리얼 생성 완료!
```

이것이 실제로 어떻게 작동하는지 간단한 코드 예제를 통해 살펴보겠습니다.

**1. 추상화 식별 (`IdentifyAbstractions`)**

이 노드는 작업할 코드 파일(`shared["files"]`)이 필요합니다.

```python
# --- nodes.py 단순화 버전 ---
class IdentifyAbstractions(Node):
    def prep(self, shared):
        files_data = shared["files"] # shared에서 입력 받음
        # ... LLM을 위한 컨텍스트와 프롬프트 준비 ...
        prompt_details = "코드 컨텍스트를 분석하고 핵심 추상화 5-10개를 식별하세요..."
        return files_data, prompt_details # exec에 필요한 데이터

    def exec(self, prep_res):
        files_data, prompt_details = prep_res
        # ... 전체 프롬프트 구성 ...
        prompt = f"코드베이스 컨텍스트: ...\n\n{prompt_details}"
        llm_response = call_llm(prompt) # 전문가(LLM)에게 질문!
        # ... LLM의 YAML 응답 파싱 ...
        # 파싱된 출력 예시:
        # [{'name': 'Config Loader', 'description': '...', 'files': [0, 2]},
        #  {'name': 'Main Runner', 'description': '...', 'files': [1, 3]}]
        parsed_abstractions = parse_llm_output(llm_response)
        return parsed_abstractions # 이 단계의 출력

    def post(self, shared, prep_res, exec_res):
        shared["abstractions"] = exec_res # 결과를 shared에 다시 저장!
```

*   `prep`: `shared`에서 필요한 데이터(`files`)를 가져옵니다.
*   `exec`: LLM을 호출하고 응답을 처리하여 추상화 목록을 얻습니다.
*   `post`: 결과(`exec_res`, 즉 추상화 목록)를 `"abstractions"` 키 아래 `shared` 딕셔너리에 다시 저장합니다.

**2. 관계 분석 (`AnalyzeRelationships`)**

이 노드는 이전에 식별된 추상화(`shared["abstractions"]`)를 사용합니다.

```python
# --- nodes.py 단순화 버전 ---
class AnalyzeRelationships(Node):
    def prep(self, shared):
        abstractions = shared["abstractions"] # shared에서 입력 받음
        files_data = shared["files"]
        # ... 추상화 및 관련 코드로 컨텍스트 준비 ...
        prompt_details = "프로젝트 요약과 주요 관계를 제공하세요..."
        return abstractions, files_data, prompt_details # exec를 위한 데이터

    def exec(self, prep_res):
        abstractions, files_data, prompt_details = prep_res
        # ... 프롬프트 구성 ...
        llm_response = call_llm("...") # 전문가에게 다시 질문!
        # ... YAML 응답 파싱 ...
        # 파싱된 출력 예시:
        # {'summary': '이 프로젝트는...',
        #  'details': [{'from': 0, 'to': 1, 'label': '사용함'}, ...]}
        parsed_relationships = parse_llm_output(llm_response)
        return parsed_relationships

    def post(self, shared, prep_res, exec_res):
        shared["relationships"] = exec_res # 요약 및 세부 정보를 shared에 저장
```

*   `prep`: `shared`에서 `abstractions` (그리고 컨텍스트를 위해 `files` 다시) 가져옵니다.
*   `exec`: LLM을 호출하여 요약 및 관계 세부 정보를 얻습니다.
*   `post`: 결과를 `shared["relationships"]`에 저장합니다.

**3. 챕터 순서 결정 (`OrderChapters`)**

추상화와 관계 모두 사용합니다.

```python
# --- nodes.py 단순화 버전 ---
class OrderChapters(Node):
    def prep(self, shared):
        abstractions = shared["abstractions"] # 입력
        relationships = shared["relationships"] # 입력
        # ... 컨텍스트 준비 ...
        prompt_details = "이 추상화들을 설명하는 가장 좋은 순서는 무엇인가요?"
        return abstractions, relationships, prompt_details

    def exec(self, prep_res):
        # ... 프롬프트 구성 ...
        llm_response = call_llm("...") # 전문가에게 순서 질문!
        # ... 인덱스의 YAML 목록 파싱 ...
        # 파싱된 출력 예시: [1, 0] (추상화 1 먼저, 다음 0)
        ordered_indices = parse_llm_output(llm_response)
        return ordered_indices

    def post(self, shared, prep_res, exec_res):
        shared["chapter_order"] = exec_res # 순서를 shared에 저장
```

**4. 챕터 작성 (`WriteChapters`)**

순서, 추상화, 파일, 관계 정보를 사용합니다. `BatchNode`이므로 `exec`는 *각* 챕터에 대해 실행됩니다.

```python
# --- nodes.py 단순화 버전 ---
class WriteChapters(BatchNode): # 참고: BatchNode는 약간 다름
    def prep(self, shared):
        chapter_order = shared["chapter_order"] # 입력
        abstractions = shared["abstractions"]   # 입력
        files_data = shared["files"]           # 입력
        # ... 각 챕터에 대한 항목 목록 준비 ...
        # 각 항목에는 특정 챕터를 작성하는 데 필요한 세부 정보 포함
        items_to_process = []
        for i, abs_index in enumerate(chapter_order):
             # ... 챕터 i+1 (추상화 abs_index)에 대한 세부 정보 수집 ...
             items_to_process.append({ "chapter_num": i+1, "details": ... })
        return items_to_process # exec를 위한 작업 목록 반환

    def exec(self, item): # prep_res의 각 항목당 한 번 실행
        chapter_num = item["chapter_num"]
        details = item["details"]
        # ... LLM에게 chapter_num 작성을 요청하는 상세 프롬프트 구성 ...
        prompt = f"{details['name']}에 대한 {chapter_num}장을 작성하세요..."
        chapter_content = call_llm(prompt) # LLM에게 작성 요청!
        return chapter_content # 이 챕터의 마크다운 내용 반환

    def post(self, shared, prep_res, exec_res_list):
        # exec_res_list는 모든 exec 호출 결과(모든 챕터) 포함
        shared["chapters"] = exec_res_list # 챕터 내용 목록 저장
```

**5. 튜토리얼 결합 (`CombineTutorial`)**

지금까지 생성된 거의 모든 것을 사용하여 최종 출력을 만듭니다.

```python
# --- nodes.py 단순화 버전 ---
class CombineTutorial(Node):
    def prep(self, shared):
        output_base_dir = shared["output_dir"] # 입력
        project_name = shared["project_name"]  # 입력
        summary = shared["relationships"]["summary"] # 입력
        relations = shared["relationships"]["details"] # 입력
        chapter_order = shared["chapter_order"] # 입력
        chapters_content = shared["chapters"]   # 입력
        abstractions = shared["abstractions"]   # 입력
        # ... 인덱스 내용 준비, Mermaid 다이어그램 문자열 생성 ...
        # ... 챕터 순서와 추상화 이름 기반으로 파일 이름 결정 ...
        # 예시: chapter_files = [{"filename": "01_intro.md", "content": "..."}, ...]
        index_md = f"# 튜토리얼: {project_name}\n{summary}\n..."
        chapter_files_to_write = [...]
        output_path = os.path.join(output_base_dir, project_name)
        return output_path, index_md, chapter_files_to_write

    def exec(self, prep_res):
        output_path, index_md, chapter_files_to_write = prep_res
        os.makedirs(output_path, exist_ok=True) # 출력 폴더 생성
        # index.md 작성
        with open(os.path.join(output_path, "index.md"), "w", encoding="utf-8") as f:
            f.write(index_md)
        # 각 챕터 파일 작성
        for file_info in chapter_files_to_write:
            with open(os.path.join(output_path, file_info["filename"]), "w", encoding="utf-8") as f:
                f.write(file_info["content"])
        return output_path # 최종 디렉토리 경로 반환

    def post(self, shared, prep_res, exec_res):
        shared["final_output_dir"] = exec_res # 출력 경로 저장
```

휴! 꽤 긴 조립 라인이죠. 각 노드는 `shared` 딕셔너리에서 특정 입력을 받아 작업을 수행하고(종종 LLM 포함), 다음 노드를 위해 결과를 `shared`에 다시 넣습니다.

## 결론

이제 튜토리얼 생성 단계가 기술 작가처럼 작동하여 원시 코드 분석을 구조화된 여러 챕터의 튜토리얼로 변환하는 방법을 보았습니다. 핵심 개념을 식별하고, 관계를 이해하고, 논리적 순서를 결정하고, 각 챕터의 내용을 작성하고, 마지막으로 모든 것을 색인과 다이어그램이 포함된 완성된 출력 디렉토리로 조립합니다.

이 과정은 분석 엔진이 제공하는 통찰력에 크게 의존합니다. 하지만 그 엔진은 실제로 어떻게 초기 통찰력(추상화 및 관계 등)을 *생성*할까요? 그것이 바로 다음 장에서 탐구할 **[3장: LLM 분석 엔진](03_llm_analysis_engine.md)**의 역할입니다!

[3장: LLM 분석 엔진](03_llm_analysis_engine.md)으로 넘어가 봅시다.

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)