from pocketflow import Flow
# Import all node classes from nodes.py
from nodes import (
    FetchRepo,
    FetchLocal,
    IdentifyAbstractions,
    AnalyzeRelationships,
    OrderChapters,
    WriteChapters,
    CombineTutorial
)

def create_tutorial_flow(shared):
    """Creates and returns the codebase tutorial generation flow."""

    # Instantiate nodes
    if shared["repo_url"].startswith("http://") or shared["repo_url"].startswith("https://"):
        fetch_base = FetchRepo()
    else:
        fetch_base = FetchLocal()
    identify_abstractions = IdentifyAbstractions(max_retries=3, wait=10)
    analyze_relationships = AnalyzeRelationships(max_retries=3, wait=10)
    order_chapters = OrderChapters(max_retries=3, wait=10)
    write_chapters = WriteChapters(max_retries=3, wait=10) # This is a BatchNode
    combine_tutorial = CombineTutorial()

    # Connect nodes in sequence based on the design
    fetch_base >> identify_abstractions
    identify_abstractions >> analyze_relationships
    analyze_relationships >> order_chapters
    order_chapters >> write_chapters
    write_chapters >> combine_tutorial

    # Create the flow starting with fetch_base
    tutorial_flow = Flow(start=fetch_base)

    return tutorial_flow
