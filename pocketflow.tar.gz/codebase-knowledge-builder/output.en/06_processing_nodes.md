# Chapter 6: Processing Nodes

```markdown
# Chapter 6: Processing Nodes

Welcome back! In [Chapter 5: Workflow Pipeline (PocketFlow)](05_workflow_pipeline__pocketflow_.md), we learned about the "assembly line manager" (PocketFlow) that orchestrates the entire tutorial generation process. It ensures that all the steps happen in the right order, from fetching code to writing the final files.

But what *are* those individual steps? What are the specialized workstations along our assembly line? That's what we'll explore in this chapter: the **Processing Nodes**.

## The Problem: Doing the Actual Work

Think about our car factory analogy again. The assembly line manager directs the flow, but they don't build the car themselves. You need specialized workers or robotic arms at different stations: one to weld the frame, one to install the engine, one to paint the body, and so on. Each station performs a specific, well-defined task.

Similarly, our workflow pipeline manager (PocketFlow) knows the *order* of tasks, but it needs individual components to actually *do* the work. How do we define these individual tasks like "fetch the code from GitHub," "ask the LLM to identify concepts," or "combine the chapters into a final output"?

## Our Solution: Specialized Workers (Processing Nodes)

**Processing Nodes** are the individual workers on our tutorial generation assembly line. Each Node is a self-contained unit designed to perform one specific task.

Here are some examples of Nodes we've encountered in previous chapters:

*   `FetchRepo`: Fetches code from a GitHub repository ([Chapter 4: Codebase Crawling](04_codebase_crawling.md)).
*   `FetchLocal`: Fetches code from a local folder ([Chapter 4: Codebase Crawling](04_codebase_crawling.md)).
*   `IdentifyAbstractions`: Asks the LLM to find key concepts ([Chapter 2: Tutorial Generation](02_tutorial_generation.md), [Chapter 3: LLM Analysis Engine](03_llm_analysis_engine.md)).
*   `AnalyzeRelationships`: Asks the LLM how concepts relate ([Chapter 2](02_tutorial_generation.md), [Chapter 3](03_llm_analysis_engine.md)).
*   `OrderChapters`: Asks the LLM for the best chapter order ([Chapter 2](02_tutorial_generation.md), [Chapter 3](03_llm_analysis_engine.md)).
*   `WriteChapters`: Asks the LLM to write the content for each chapter ([Chapter 2](02_tutorial_generation.md)).
*   `CombineTutorial`: Gathers all the pieces and writes the final tutorial files ([Chapter 2](02_tutorial_generation.md)).

Each Node acts like a specialist: it takes specific inputs, performs its unique task, and produces specific outputs, which are then often used by the next Node in the pipeline.

## Inside a Node: The Prep-Execute-Post Cycle

How does a Node actually perform its task? Most Nodes in our project follow a simple three-step lifecycle, managed by PocketFlow:

1.  **`prep(shared)` (Prepare / Get Ready):**
    *   **Purpose:** Gather all the necessary ingredients (data) needed for the task from the central `shared` dictionary.
    *   **Analogy:** Before a baker starts baking, they gather the flour, sugar, eggs (inputs) from the pantry (`shared` dictionary).
    *   **Input:** The current `shared` dictionary.
    *   **Output:** Returns the specific data the `exec` step needs.

2.  **`exec(prep_res)` (Execute / Do the Work):**
    *   **Purpose:** Perform the Node's core task using the prepared ingredients. This might involve calling helper functions (like `crawl_local_files` or `call_llm`), processing data, or running calculations.
    *   **Analogy:** The baker mixes the ingredients and puts the cake in the oven (performs the main task).
    *   **Input:** The data returned by the `prep` step (`prep_res`).
    *   **Output:** Returns the result of the task (e.g., the list of fetched files, the identified abstractions, the written chapter content).

3.  **`post(shared, prep_res, exec_res)` (Post-process / Store Result):**
    *   **Purpose:** Take the result from the `exec` step and store it back into the `shared` dictionary, making it available for subsequent Nodes. It can also perform cleanup or final logging.
    *   **Analogy:** The baker takes the finished cake (the result) and places it on the cooling rack (`shared` dictionary) for the next step (decorating).
    *   **Input:** The `shared` dictionary, the data from `prep` (`prep_res`), and the result from `exec` (`exec_res`).
    *   **Output:** Updates the `shared` dictionary in place.

PocketFlow calls these three methods in sequence for each Node in the workflow.

Here’s a diagram showing how PocketFlow interacts with a Node using this cycle:

```mermaid
sequenceDiagram
    participant PF as PocketFlow Engine
    participant Node as Processing Node
    participant Shared as shared Dictionary

    Note over PF, Node: Start processing a Node...
    PF->>Node: Calls node.prep(shared)
    Node->>Shared: Reads needed data (e.g., repo_url)
    Node-->>PF: Returns prepared data (prep_res)
    PF->>Node: Calls node.exec(prep_res)
    Note right of Node: Performs core task...<br/>(e.g., calls crawl_local_files, call_llm)
    Node-->>PF: Returns result (exec_res)
    PF->>Node: Calls node.post(shared, prep_res, exec_res)
    Node->>Shared: Writes result back (e.g., shared["files"] = exec_res)
    Node-->>PF: Post-processing finished
    Note over PF, Node: Node processing complete!
```

## A Look at the Code: `nodes.py`

All our specialist workers (Nodes) are defined as Python classes in the `nodes.py` file. They inherit from `pocketflow.Node` (or sometimes `pocketflow.BatchNode`) and implement the `prep`, `exec`, and `post` methods.

Let's look at simplified examples:

**Example 1: `FetchLocal` (Simplified)**

This Node fetches files from a local directory.

```python
# --- Simplified from nodes.py ---
from pocketflow import Node
from utils.crawl_local_files import crawl_local_files # Helper function

class FetchLocal(Node):
    # Step 1: Prepare - Get instructions from shared dictionary
    def prep(self, shared):
        print("FetchLocal: Preparing...")
        # Get needed info (the path, filters) from shared
        config = {
            "repo_url": shared["repo_url"],
            "include_patterns": shared["include_patterns"],
            # ... other filters ...
        }
        return config # Return the config for exec

    # Step 2: Execute - Call the librarian utility
    def exec(self, prep_res):
        print(f"FetchLocal: Executing crawl for {prep_res['repo_url']}...")
        # Call the actual crawling function with prepared config
        result = crawl_local_files(**prep_res) # Pass config directly
        # Get the list of files: [(path1, content1), ...]
        files_list = list(result.get("files", {}).items())
        print(f"FetchLocal: Fetched {len(files_list)} files.")
        return files_list # Return the list of fetched files

    # Step 3: Post-process - Store the results in shared
    def post(self, shared, prep_res, exec_res):
        print("FetchLocal: Storing results...")
        # Store the list of (path, content) tuples in the shared dictionary
        shared["files"] = exec_res # exec_res is the files_list
        print("FetchLocal: Done.")
```

*   `prep`: Reads configuration like `repo_url` and filters from the `shared` dictionary.
*   `exec`: Calls the `crawl_local_files` function (the actual file fetching logic from [Chapter 4](04_codebase_crawling.md)) using the prepared configuration. It returns the list of files found.
*   `post`: Takes the list of files returned by `exec` (`exec_res`) and saves it into the `shared` dictionary under the key `"files"`.

**Example 2: `IdentifyAbstractions` (Simplified)**

This Node asks the LLM to identify core concepts.

```python
# --- Simplified from nodes.py ---
from pocketflow import Node
from utils.call_llm import call_llm # Helper to call the LLM

class IdentifyAbstractions(Node):
    # Step 1: Prepare - Get files data and prepare context
    def prep(self, shared):
        print("IdentifyAbstractions: Preparing...")
        files_data = shared["files"] # Get files from the previous step
        # In reality, creates a formatted context and prompt details
        context_for_llm = "Code context based on files_data..."
        prompt_details = "Identify top abstractions..."
        print("IdentifyAbstractions: Prepared context for LLM.")
        return context_for_llm, prompt_details, len(files_data)

    # Step 2: Execute - Call the LLM
    def exec(self, prep_res):
        context, details, file_count = prep_res
        print("IdentifyAbstractions: Executing LLM call...")
        # Construct the full prompt and call the LLM
        prompt = f"{context}\n\n{details}"
        response_text = call_llm(prompt) # Ask the expert!
        # In reality, parses the YAML response
        parsed_abstractions = [{"name": "Example", "files": [0]}] # Dummy parsed result
        print(f"IdentifyAbstractions: Received {len(parsed_abstractions)} abstractions.")
        return parsed_abstractions # Return the list of abstractions

    # Step 3: Post-process - Store the abstractions
    def post(self, shared, prep_res, exec_res):
        print("IdentifyAbstractions: Storing results...")
        # Store the list of abstractions from exec_res in shared
        shared["abstractions"] = exec_res
        print("IdentifyAbstractions: Done.")
```

*   `prep`: Gets the list of files (`shared["files"]`) that `FetchLocal` (or `FetchRepo`) put there. It prepares the necessary text context and instructions for the LLM.
*   `exec`: Calls the `call_llm` function (from [Chapter 3](03_llm_analysis_engine.md)) with the prepared prompt. It receives the LLM's response and parses it into a structured list of abstractions.
*   `post`: Takes the list of abstractions returned by `exec` (`exec_res`) and saves it into the `shared` dictionary under the key `"abstractions"`, ready for the `AnalyzeRelationships` node.

**A Note on `BatchNode` (`WriteChapters`)**

You might notice `WriteChapters` inherits from `BatchNode`. This is a special type of Node used when you need to perform the *same* execution logic on *multiple* items.

*   `prep`: Prepares a *list* of items to be processed (e.g., a list where each item contains the details needed to write one specific chapter).
*   `exec`: Runs *once for each item* in the list prepared by `prep`.
*   `post`: Receives a *list* of results, one from each `exec` call.

It's like having one worker (the `WriteChapters` Node) who takes a stack of chapter outlines (`prep` result), writes each chapter individually (`exec` called multiple times), and then bundles all the finished chapters together (`post` receives list of results).

## Conclusion

Processing Nodes are the fundamental building blocks of our workflow pipeline. They are the specialized workers on the assembly line, each performing a distinct task like fetching code, analyzing it with an LLM, or writing output files. Most nodes follow a `prep` -> `exec` -> `post` lifecycle managed by PocketFlow, using the `shared` dictionary to receive inputs and store outputs, ensuring data flows smoothly from one step to the next.

Understanding Nodes helps you see how the complex task of tutorial generation is broken down into smaller, manageable steps, each implemented as a focused Python class in `nodes.py`.

With this chapter, we've covered all the core conceptual components of the tutorial generator: configuration, the overall generation process, the LLM engine, codebase crawling, the workflow pipeline, and the processing nodes that do the work. You now have a solid foundation for understanding how this project operates!
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)