# Chapter 5: Workflow Pipeline (PocketFlow)

```markdown
# Chapter 5: Workflow Pipeline (PocketFlow)

Welcome back! In the previous chapters, we've explored some fascinating parts of our tutorial generator:

*   [Chapter 1: Configuration & Execution](01_configuration___execution.md): How we start the process and give it instructions.
*   [Chapter 2: Tutorial Generation](02_tutorial_generation.md): How the tutorial's structure and content are planned and written.
*   [Chapter 3: LLM Analysis Engine](03_llm_analysis_engine.md): The "expert consultant" (LLM) that understands the code.
*   [Chapter 4: Codebase Crawling](04_codebase_crawling.md): The "librarian" that fetches the source code files.

We've seen individual tasks like fetching files, identifying concepts, analyzing relationships, ordering chapters, writing content, and combining the final output. But how does the system ensure these tasks happen in the *correct order*? What manages the overall process, making sure the output of one step becomes the input for the next?

That's where the **Workflow Pipeline**, powered by a small library called **PocketFlow**, comes in!

## The Problem: Managing a Complex Process

Imagine building a car. You have different stations: one for the chassis, one for the engine, one for painting, one for installing seats, etc. You can't paint the car before the chassis is built, and you can't install seats before the painting is done. The order matters!

Our tutorial generator is similar. We need to perform several steps in a specific sequence:

1.  **Fetch** the code (Can't analyze code we don't have!).
2.  **Identify** the main concepts (Need concepts before analyzing relationships).
3.  **Analyze** how concepts relate (Need relationships before ordering chapters).
4.  **Order** the chapters logically.
5.  **Write** the content for each chapter.
6.  **Combine** everything into the final tutorial files.

Doing these steps manually or out of order would lead to errors or nonsensical results. We need a manager to oversee this assembly line.

## Our Solution: The Assembly Line Manager (PocketFlow)

Think of **PocketFlow** as the manager of our tutorial factory's assembly line. Its job is to:

1.  **Know the sequence:** Understand the exact order in which tasks (called **Nodes**) must be performed.
2.  **Direct the flow:** Ensure the codebase information moves correctly from one station (Node) to the next.
3.  **Manage execution:** Start the assembly line and make sure each station does its job before passing the work along.

PocketFlow provides a simple way to define this sequence of operations and run it smoothly.

## Defining the Assembly Line: `flow.py`

How do we tell PocketFlow the correct order of our tasks? We define it in a specific file, `flow.py`, using a function called `create_tutorial_flow`. Let's look at a simplified version:

```python
# --- Simplified from flow.py ---
from pocketflow import Flow
# Import the 'Node' classes (our workstations)
from nodes import (
    FetchRepo, FetchLocal, IdentifyAbstractions,
    AnalyzeRelationships, OrderChapters, WriteChapters, CombineTutorial
)

def create_tutorial_flow(shared):
    """Creates and returns the codebase tutorial generation flow."""

    # 1. Decide which 'fetching' node to use based on input URL
    if shared["repo_url"].startswith("http"):
        fetch_node = FetchRepo() # Use GitHub fetcher
    else:
        fetch_node = FetchLocal() # Use local folder fetcher

    # 2. Create instances of all other nodes (workstations)
    # (max_retries tells PocketFlow to retry if a step fails)
    identify_node = IdentifyAbstractions(max_retries=3)
    analyze_node = AnalyzeRelationships(max_retries=3)
    order_node = OrderChapters(max_retries=3)
    write_node = WriteChapters(max_retries=3)
    combine_node = CombineTutorial()

    # 3. Define the sequence using the '>>' operator
    # This means 'output of fetch_node goes to identify_node', etc.
    fetch_node >> identify_node >> analyze_node >> order_node \
               >> write_node >> combine_node

    # 4. Create the final Flow object, starting with the fetch_node
    tutorial_flow = Flow(start=fetch_node)

    return tutorial_flow
```

**Explanation:**

1.  **Choose Fetcher:** Based on whether the `repo_url` (from Chapter 1's `shared` dictionary) is a web URL or a local path, it decides whether to use the `FetchRepo` node or the `FetchLocal` node as the starting point.
2.  **Instantiate Nodes:** It creates an object for each step (Node) in our process. Think of this as setting up each workstation on the assembly line. We'll learn more about what's inside these Nodes in [Chapter 6: Processing Nodes](06_processing_nodes.md).
3.  **Connect Nodes (`>>`):** This is the crucial part! The `>>` operator tells PocketFlow the order. `fetch_node >> identify_node` means "after `fetch_node` finishes, run `identify_node`." We chain them together to define the entire sequence: Fetch -> Identify -> Analyze -> Order -> Write -> Combine.
4.  **Create Flow:** Finally, it creates the `Flow` object, telling PocketFlow that the `fetch_node` is the very first step.

This `create_tutorial_flow` function essentially builds the blueprint for our assembly line.

## Starting the Assembly Line: `main.py`

Remember back in [Chapter 1: Configuration & Execution](01_configuration___execution.md), after parsing arguments and creating the `shared` dictionary, `main.py` did this:

```python
# --- Snippet from main.py ---
from flow import create_tutorial_flow # Import the blueprint function

# ... (parsing args and creating shared dict happens here) ...

# Create the flow instance using the blueprint
tutorial_flow = create_tutorial_flow(shared)

# Run the flow - START THE ASSEMBLY LINE!
print("Starting tutorial generation workflow...")
tutorial_flow.run(shared)
print("Workflow finished.")
```

1.  It calls `create_tutorial_flow(shared)` to get the configured assembly line blueprint (the `Flow` object).
2.  Then, `tutorial_flow.run(shared)` is called. This is like pressing the big "Start" button on the assembly line!

## How PocketFlow Runs the Show

When `tutorial_flow.run(shared)` is called, PocketFlow takes over:

1.  **Start Node:** It looks at the `start` node defined in the `Flow` object (which is either `FetchRepo` or `FetchLocal`).
2.  **Execute Node:** It runs the first node. As we'll see in Chapter 6, each node has steps like `prep` (prepare inputs from `shared`), `exec` (do the actual work), and `post` (save results back to `shared`). PocketFlow manages calling these methods.
3.  **Pass Data via `shared`:** The crucial `shared` dictionary is passed to each node. When `FetchLocal` finishes, it puts the list of files into `shared["files"]`.
4.  **Next Node:** PocketFlow looks at the connections (`>>`). It sees that `IdentifyAbstractions` comes after the fetch node.
5.  **Execute Next Node:** It runs `IdentifyAbstractions`. This node reads `shared["files"]`, does its LLM analysis ([Chapter 3](03_llm_analysis_engine.md)), and saves the results in `shared["abstractions"]`.
6.  **Repeat:** PocketFlow continues following the `>>` connections, running `AnalyzeRelationships` (using `shared["abstractions"]`, saving `shared["relationships"]`), then `OrderChapters`, `WriteChapters`, and finally `CombineTutorial`, each time using and updating the `shared` dictionary.
7.  **Finish:** Once the last node (`CombineTutorial`) finishes, the `run()` call completes, and `main.py` prints "Workflow finished."

Here’s a diagram illustrating how PocketFlow executes the sequence:

```mermaid
sequenceDiagram
    participant Main as main.py
    participant PF as PocketFlow Engine
    participant Fetch as Fetch Node
    participant Identify as Identify Node
    participant Analyze as Analyze Node
    participant Shared as shared Dictionary

    Main->>PF: Calls flow.run(shared)
    PF->>Fetch: Execute Node 1 (Fetch)
    Note right of Fetch: Reads config from shared<br/>Fetches files
    Fetch->>Shared: Writes results to shared["files"]
    Fetch-->>PF: Node 1 Finished
    PF->>Identify: Execute Node 2 (Identify)
    Note right of Identify: Reads shared["files"]<br/>Calls LLM
    Identify->>Shared: Writes results to shared["abstractions"]
    Identify-->>PF: Node 2 Finished
    PF->>Analyze: Execute Node 3 (Analyze)
    Note right of Analyze: Reads shared["abstractions"]<br/>Calls LLM
    Analyze->>Shared: Writes results to shared["relationships"]
    Analyze-->>PF: Node 3 Finished
    Note over PF: ... continues for Order, Write, Combine ...
    PF-->>Main: Workflow Complete
```

PocketFlow acts as the conductor, ensuring each part plays at the right time and that information is passed along correctly via the `shared` dictionary. It also handles things like retrying a node if it fails (thanks to the `max_retries=3` we saw earlier).

## Conclusion

The Workflow Pipeline, managed by PocketFlow, is the backbone of our tutorial generator. It solves the problem of orchestrating a complex sequence of tasks by acting like an assembly line manager. We define the sequence of steps (Nodes) and their connections (`>>`) in `flow.py`, and then `main.py` starts the process using `flow.run(shared)`. PocketFlow ensures each node runs in the correct order, passing data between them using the central `shared` dictionary.

This organized approach makes the complex process of fetching code, analyzing it, and generating a tutorial manageable and reliable.

Now that we understand how the *overall* flow is managed, let's zoom in on the individual workstations on our assembly line. What exactly happens inside each Node?

Let's move on to [Chapter 6: Processing Nodes](06_processing_nodes.md) to find out!
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)