# Chapter 3: LLM Analysis Engine

```markdown
# Chapter 3: LLM Analysis Engine

Welcome back! In [Chapter 2: Tutorial Generation](02_tutorial_generation.md), we saw how the tutorial generator acts like a technical writer, taking raw analysis about a codebase and turning it into a structured, multi-chapter tutorial. We learned about the different steps involved, like identifying key concepts (abstractions), analyzing how they connect, deciding the chapter order, and writing the content.

But where did that initial "raw analysis" come from? How did the system know which parts of the code were important or how they related to each other? That's the magic performed by the **LLM Analysis Engine**, the focus of this chapter!

## The Problem: Understanding Complex Code Automatically

Imagine you're given a huge, unfamiliar codebase with thousands of lines across many files. Your task is to write a tutorial explaining its most important parts to a beginner. Where would you even start? Reading everything would take days or weeks!

This is the challenge our tutorial generator faces. It needs to quickly grasp the essence of a codebase – its main components, their purpose, and how they interact – without a human spending hours reading it. How can we automate this understanding?

## Our Solution: The Expert Consultant (LLM Analysis Engine)

Think of the LLM Analysis Engine as an incredibly fast, knowledgeable expert consultant. You can hand this consultant a pile of project documents (the codebase files), and they can quickly read through them, identify the crucial ideas, figure out how they fit together, and even suggest the best way to explain them.

This engine uses a **Large Language Model (LLM)** – a type of artificial intelligence trained on vast amounts of text and code. LLMs are remarkably good at understanding patterns, summarizing information, and answering questions about the content they are given.

Our LLM Analysis Engine leverages this power to:

1.  **Identify Key Abstractions:** It reads the code and picks out the most important concepts or components (like the `IdentifyAbstractions` node we saw in Chapter 2 needed).
2.  **Analyze Relationships:** It figures out how these key concepts interact (e.g., "Component A uses Component B," needed by `AnalyzeRelationships`).
3.  **Determine Logical Order:** It suggests the best sequence to explain these concepts to a newcomer (needed by `OrderChapters`).

Essentially, it provides the core understanding and insights that the Tutorial Generation process (Chapter 2) uses to build the final tutorial.

## How It Works: Asking the Right Questions

The LLM Analysis Engine doesn't just magically understand the code. The other parts of the system, specifically the **Processing Nodes** (like `IdentifyAbstractions`, `AnalyzeRelationships`, `OrderChapters` – which we'll explore more in [Chapter 6: Processing Nodes](06_processing_nodes.md)), need to interact with it.

Think of it like this: the nodes are like managers who know *what* information they need. The LLM Analysis Engine is the consultant who can *find* that information if asked correctly.

Here’s the typical workflow:

1.  **Prepare the Question (Prompt):** A node (like `IdentifyAbstractions`) gathers the relevant code files fetched by the [Codebase Crawling](04_codebase_crawling.md) step. It then formulates a specific question, called a **prompt**, designed to get the information it needs from the LLM. This prompt includes the code context and clear instructions on what to identify and how to format the answer.

    *Example Simplified Prompt (for identifying abstractions):*
    ```
    Analyze the following code files:
    --- File 0: main.py ---
    # code...
    --- File 1: utils.py ---
    # code...

    Identify the top 5 core abstractions. For each, provide a name,
    a beginner-friendly description, and the relevant file indices.
    Format the output as YAML.
    ```

2.  **Ask the Expert (`call_llm`):** The node passes this detailed prompt to a helper function, typically something like `utils/call_llm.py`. This function is the core communication channel to the LLM Analysis Engine.

3.  **LLM Processes:** The `call_llm` function sends the prompt to the actual Large Language Model service (like Google's Gemini). The LLM reads the prompt and the provided code context, performs its analysis based on its training, and generates a text-based answer.

4.  **Receive the Answer:** The `call_llm` function gets the LLM's text response back.

    *Example LLM Response (YAML format):*
    ```yaml
    - name: Configuration Loader
      description: Loads settings... like reading instructions.
      file_indices: [0]
    - name: Main Runner
      description: Starts the process... like pressing the start button.
      file_indices: [0, 1]
    # ... more abstractions ...
    ```

5.  **Parse and Use:** The node that originally asked the question receives the response text from `call_llm`. It then parses this text (e.g., converting the YAML string into a Python list of dictionaries) and extracts the needed information (the list of abstractions in this case). This information is then stored in the `shared` dictionary for other nodes to use.

Here’s a sequence diagram showing this interaction:

```mermaid
sequenceDiagram
    participant Node as Processing Node (e.g., IdentifyAbstractions)
    participant CallLLM as utils.call_llm.py
    participant LLMEngine as LLM Analysis Engine (Conceptual + LLM Service)
    participant Shared as shared Dictionary

    Node->>Node: Prepare Prompt with Code Context
    Node->>CallLLM: call_llm(prompt)
    CallLLM->>LLMEngine: Send Prompt to LLM API
    LLMEngine->>LLMEngine: Analyze Code & Generate Response
    LLMEngine-->>CallLLM: Return Text Response
    CallLLM-->>Node: Return Text Response
    Node->>Node: Parse Response (e.g., YAML)
    Node->>Shared: Store Parsed Results (e.g., abstractions)
```

## Under the Hood: The `call_llm` Utility

The central piece of code enabling this interaction is the `utils/call_llm.py` utility. Its job is simple but crucial: send a question (prompt) to the LLM and return the answer.

Here's a highly simplified view of what `call_llm` does:

```python
# --- Simplified from utils/call_llm.py ---
import os
# Assume 'genai' is the library for the LLM service (e.g., Google Gemini)
from google import genai
import logging # For recording calls

logger = logging.getLogger(__name__)

# Function to interact with the LLM
def call_llm(prompt: str) -> str:
    """Sends a prompt to the LLM and returns the text response."""

    logger.info(f"Sending prompt to LLM (first 50 chars): {prompt[:50]}...")

    try:
        # 1. Configure the LLM client (needs API key usually)
        api_key = os.getenv("GEMINI_API_KEY") # Get API key from environment
        client = genai.Client(api_key=api_key)
        model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash") # Choose a model

        # 2. Send the prompt to the specified model
        response = client.models.generate_content(
            model=model_name,
            contents=[prompt] # The actual question/prompt
        )

        # 3. Extract the text answer
        response_text = response.text
        logger.info("Received response from LLM.")
        return response_text

    except Exception as e:
        logger.error(f"Error calling LLM: {e}")
        # In a real scenario, might retry or return an error message
        return "Error: Could not get response from LLM."

```

**Explanation:**

1.  **Logging:** It records that a prompt is being sent (useful for debugging).
2.  **Configuration:** It sets up the connection to the LLM service, often requiring an API key (like a password) which is usually stored securely as an environment variable (`os.getenv`). It also specifies which LLM model to use (different models have different capabilities and costs).
3.  **Sending Prompt:** The core action! It sends the `prompt` string to the LLM service using the client library (`client.models.generate_content`).
4.  **Getting Response:** It receives the response object from the LLM and extracts the actual text content (`response.text`).
5.  **Return:** It returns this text back to the node that called it.
6.  **Error Handling:** Includes basic error catching in case the LLM call fails.

*(Note: The actual `call_llm.py` in the project also includes caching to save time and costs by reusing previous answers for identical prompts, but we've omitted that here for simplicity.)*

This `call_llm` function acts as the bridge, allowing different parts of our system (the nodes) to tap into the analytical power of the LLM without needing to know the complex details of the LLM API interaction.

## Conclusion

The LLM Analysis Engine is the "brain" of our tutorial generator when it comes to understanding the codebase. It acts like an expert consultant, using a Large Language Model to analyze the code provided to it. By answering specific questions (prompts) posed by different processing nodes, it identifies key abstractions, analyzes their relationships, and determines a logical explanation order. This automated analysis, facilitated by the `call_llm` utility, provides the essential insights needed by the [Tutorial Generation](02_tutorial_generation.md) process to create a meaningful and structured tutorial.

Now we understand how the system *understands* the code. But how did the system get the code files in the first place, especially from different sources like GitHub or local folders? That's the job of the Codebase Crawler, which we'll explore next!

Let's move on to [Chapter 4: Codebase Crawling](04_codebase_crawling.md).
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)