# Chapter 1: Configuration & Execution

Welcome to the tutorial generator! Ever wonder how a complex piece of software like this actually *starts* running? How do you tell it which code project you want a tutorial for, or where you want the final tutorial files to be saved? That's what this chapter is all about!

Think of this project like a sophisticated assembly line designed to build a tutorial for a codebase. This first step, "Configuration & Execution," is like the main control panel for that assembly line. It's where you, the operator, set all the important parameters (like *which* product to build – which codebase?) and then press the big "Start" button.

**Our Goal:** Let's imagine you have a small project stored locally on your computer (not on GitHub) in a folder called `my_awesome_project`, and you want to generate a tutorial for it, saving the output into a new folder named `my_tutorial`. How do you tell the generator to do exactly that?

## What Are Command-Line Arguments?

Most programs need some initial instructions to get started. Instead of complex graphical interfaces, many developer tools use the **command line** (that text-based window often called a Terminal or Command Prompt). You type commands, and the computer responds.

When you run our tutorial generator, you can add extra pieces of information right after the command – these are called **command-line arguments**. They act like settings or options you provide upfront.

It's like setting preferences before starting a video game: Do you want easy or hard mode? What character will you play? Command-line arguments let you specify things like:

*   **Where is the code?** (Is it on GitHub? Or a local folder?)
*   **Where should the output go?**
*   **Are there specific files to include or ignore?**
*   **Do you need special access (like a GitHub token)?**

## Running the Generator (`main.py`)

The main entry point, the "Start" button for our assembly line, is a file named `main.py`. You run this file using Python from your command line.

To handle the arguments (our settings), `main.py` uses a standard Python tool called `argparse`. Let's look at a simplified snippet showing how it defines some of the arguments we can use:

```python
# --- File: main.py ---
import argparse

# Create an argument parser
parser = argparse.ArgumentParser(description="Generate a tutorial...")

# Define the 'repo_url' argument (required)
parser.add_argument("repo_url", help="URL of the public GitHub repository or Local path of Source Files.")

# Define the 'output' argument (optional, with a default)
parser.add_argument("-o", "--output", default="output", help="Base directory for output (default: ./output).")

# Define 'include' and 'exclude' arguments (optional)
parser.add_argument("-i", "--include", nargs="+", help="Include file patterns...")
parser.add_argument("-e", "--exclude", nargs="+", help="Exclude file patterns...")

# ... other arguments defined here ...

# --- This part happens later in main() ---
# Actually parse the arguments provided by the user
# args = parser.parse_args()
```

*   `argparse.ArgumentParser(...)`: Creates a helper object to manage arguments.
*   `parser.add_argument(...)`: Defines a specific argument the program can accept.
    *   `"repo_url"`: This is a *positional* argument – it's required and doesn't need a flag like `-o`.
    *   `"-o", "--output"`: This is an *optional* argument. You can use either `-o` or `--output`. It has a `default` value ("output") if you don't provide it.
    *   `nargs="+` means you can list multiple patterns after `--include` or `--exclude`.

## Solving Our Use Case

Remember our goal? Generate a tutorial for a local folder `my_awesome_project` and save it to `my_tutorial`. Using the arguments we just learned about, you would open your command line, navigate to the directory containing the tutorial generator project, and type:

```bash
python main.py ./my_awesome_project -o ./my_tutorial
```

Let's break this command down:

*   `python main.py`: Tells the computer to run the `main.py` script using Python.
*   `./my_awesome_project`: This is the value for the required `repo_url` argument. We're providing a local path.
*   `-o ./my_tutorial`: This uses the `-o` flag (short for `--output`) to specify that the output should go into a directory named `my_tutorial` in the current location.

When you run this, the `main.py` script starts up!

## What Happens Next? Under the Hood

So you've pressed "Start" by running the command. What does `main.py` do with your instructions?

1.  **Parse Arguments:** It uses `args = parser.parse_args()` (which we commented out earlier) to read the arguments you provided (`./my_awesome_project` and `./my_tutorial`).
2.  **Store Configuration:** It gathers all the configuration details (your arguments, plus some default values for things you didn't specify, like file filters) into a Python dictionary, often called `shared`. This dictionary acts like a central message board where different parts of the assembly line can read settings and store results.

    ```python
    # --- File: main.py ---

    # ... (argument parsing happens here) ...
    # args = parser.parse_args()

    # Initialize the shared dictionary with inputs
    shared = {
        "repo_url": args.repo_url, # Value is './my_awesome_project'
        "project_name": args.name, # We didn't provide -n, so this is None for now
        "github_token": github_token, # Might be None if not provided
        "output_dir": args.output, # Value is './my_tutorial'

        # Default patterns if -i or -e weren't used
        "include_patterns": set(args.include) if args.include else DEFAULT_INCLUDE_PATTERNS,
        "exclude_patterns": set(args.exclude) if args.exclude else DEFAULT_EXCLUDE_PATTERNS,
        # ... other shared data initialized ...
    }
    print(f"Starting tutorial generation for: {args.repo_url}")
    ```

    This `shared` dictionary is crucial. It carries the instructions and data through the entire tutorial generation process.

3.  **Create the Workflow:** It calls a function `create_tutorial_flow` (imported from `flow.py`). This function builds the actual sequence of steps (the assembly line) needed to generate the tutorial. We'll explore this more in the [Workflow Pipeline (PocketFlow)](05_workflow_pipeline__pocketflow_.md) chapter.

    ```python
    # --- File: main.py ---
    from flow import create_tutorial_flow # Import the function

    # ... (parsing args and creating shared dict) ...

    # Create the flow instance
    tutorial_flow = create_tutorial_flow(shared)
    ```

4.  **Run the Workflow:** Finally, it tells the workflow to start processing, passing in the `shared` dictionary containing all our configuration.

    ```python
    # --- File: main.py ---

    # ... (previous steps) ...

    # Run the flow
    tutorial_flow.run(shared)
    # The assembly line starts working now!
    ```

Here’s a simplified view of how the components interact when you run the script:

```mermaid
sequenceDiagram
    participant U as User
    participant M as main.py
    participant F as flow.py
    participant P as PocketFlow (Workflow Engine)

    U->>M: Runs `python main.py ./my_proj -o ./tut`
    M->>M: Parses arguments (`repo_url`, `output`, etc.)
    M->>M: Creates `shared` dictionary with config
    M->>F: Calls `create_tutorial_flow(shared)`
    F->>P: Defines sequence of steps (Nodes)
    F-->>M: Returns configured Workflow (Flow object)
    M->>P: Calls `flow.run(shared)`
    Note right of P: Workflow executes steps:<br/>1. Fetch Code<br/>2. Analyze<br/>3. ... etc ...<br/>(using/updating `shared` dict)
    P-->>M: Execution finishes
```

This `flow.run(shared)` call kicks off the entire chain of events: fetching the code ([Codebase Crawling](04_codebase_crawling.md)), analyzing it using language models ([LLM Analysis Engine](03_llm_analysis_engine.md)), figuring out chapter structure ([Tutorial Generation](02_tutorial_generation.md)), and finally writing the tutorial files.

## Conclusion

You've learned how to start the tutorial generator using the `main.py` script and how to configure its behavior using command-line arguments like `repo_url` (for the code location) and `--output` (for the results). You also saw how these configurations are gathered into a `shared` dictionary and used to kick off the main workflow.

You now know how to operate the "control panel" and press "Start"!

Next, we'll dive into one of the first major tasks the workflow performs: figuring out the high-level concepts in the code to decide what the tutorial chapters should be about. Let's move on to [Chapter 2: Tutorial Generation](02_tutorial_generation.md).

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)