# Chapter 4: Codebase Crawling

```markdown
# Chapter 4: Codebase Crawling

Welcome back! In [Chapter 3: LLM Analysis Engine](03_llm_analysis_engine.md), we explored the "brain" of our system – the LLM that analyzes code to find key concepts and relationships. It's like an expert consultant who reads the project documents and provides insights.

But wait... where do those "project documents" (the source code files) actually come from? Before the LLM can analyze anything, we first need to *get* the code! That's the job of the **Codebase Crawler**.

## The Problem: Getting the Right Code

Imagine you want our tutorial generator to explain a cool project you found. Maybe it's hosted online on GitHub, or perhaps it's a project you've downloaded to your own computer. How does the generator know where to find the code? And what if the project folder contains lots of extra files we *don't* want in the tutorial, like test scripts, build outputs, or huge data files? We need a way to fetch *only* the relevant source code.

## Our Solution: The Digital Librarian (Codebase Crawler)

Think of the Codebase Crawler as a very efficient **librarian**. Its job is to retrieve books (code files) for analysis. This librarian is quite versatile:

1.  **Online Digital Library (GitHub):** If you provide a GitHub URL, the librarian knows how to go online, find the specific repository, and download the files.
2.  **Local Library Shelves (Your Computer):** If you provide a path to a folder on your computer, the librarian can walk over to the shelves and pick up the files from there.

But this librarian is also smart! You can give it **special instructions**:

*   **"Only bring me Python books!"** (Include patterns, e.g., `*.py`)
*   **"Ignore anything from the 'tests' or 'docs' sections."** (Exclude patterns, e.g., `tests/*`, `docs/*`)
*   **"Don't bring anything heavier than 100 pages!"** (Maximum file size limit)

The Codebase Crawler follows these instructions precisely, ensuring it only gathers the source code files that are truly needed for creating the tutorial, saving time and resources.

## How Do You Tell the Librarian What to Do?

Remember back in [Chapter 1: Configuration & Execution](01_configuration___execution.md)? We used command-line arguments to start the generator. Some of those arguments were the instructions for our librarian!

Let's revisit that:

```bash
# Example 1: Fetching from GitHub
python main.py https://github.com/someuser/someproject -o ./my_tutorial

# Example 2: Fetching from a Local Folder
python main.py ./my_awesome_project -o ./my_tutorial

# Example 3: Fetching with Filters (Local Folder)
python main.py ./my_awesome_project -o ./my_tutorial \
    -i "*.py" "*.js" \
    -e "tests/*" "build/*" \
    -s 50000
```

*   **The First Argument (`repo_url`):** This tells the librarian *where* to look. It can be a `https://github.com/...` URL or a local path like `./my_awesome_project`.
*   **`--include` (`-i`):** Tells the librarian *only* to get files matching these patterns (like `*.py` for Python files).
*   **`--exclude` (`-e`):** Tells the librarian to *ignore* files or folders matching these patterns.
*   **`--max-size` (`-s`):** Tells the librarian to skip any file larger than this size (in bytes). 50000 bytes is about 50KB.

When you run `main.py`, it reads these arguments and stores them in the `shared` dictionary we've talked about.

## Under the Hood: The Crawling Process

So, you've given the instructions via the command line. What happens inside the system?

1.  **Decision Time:** The workflow (which we'll discuss more in [Chapter 5: Workflow Pipeline (PocketFlow)](05_workflow_pipeline__pocketflow_.md)) looks at the `repo_url` you provided in the `shared` dictionary.
    *   If it looks like a GitHub URL, it decides to use the `FetchRepo` node (a specialist for GitHub).
    *   If it looks like a local path, it decides to use the `FetchLocal` node (a specialist for local folders).

2.  **Fetching the Files:** Let's follow the path for a local folder (`FetchLocal`):
    *   **Preparation (`prep`):** The `FetchLocal` node reads the `repo_url`, `include_patterns`, `exclude_patterns`, and `max_file_size` from the `shared` dictionary.
    *   **Execution (`exec`):** It calls a helper utility function called `crawl_local_files`, passing along the path and the filter rules.
    *   **Crawling (`crawl_local_files`):** This utility function acts like the librarian physically walking the aisles:
        *   It uses Python's `os.walk` to go through every file in the specified directory and its subdirectories.
        *   For each file, it checks:
            *   Does the filename match any `include_patterns`? (Using `fnmatch`)
            *   Does the file path match any `exclude_patterns`? (Using `fnmatch`)
            *   Is the file size (`os.path.getsize`) less than `max_file_size`?
        *   If a file passes all checks, the librarian opens it, reads its content, and stores the file's relative path and its content. Files that fail the checks are skipped.
    *   **Storing Results (`post`):** The `FetchLocal` node receives the list of (path, content) pairs back from the utility. It then stores this list in the `shared` dictionary under the key `"files"`.

Here's a simplified diagram of the local fetching process:

```mermaid
sequenceDiagram
    participant M as main.py
    participant WF as Workflow Engine
    participant FL as FetchLocal Node
    participant CLF as crawl_local_files util
    participant Shared as shared Dictionary

    M->>M: Parse args (repo_url=./proj, include, etc.)
    M->>Shared: Store args in shared dict
    M->>WF: Start flow.run(shared)
    WF->>FL: Execute FetchLocal Node
    FL->>Shared: Read repo_url, filters from shared
    FL->>CLF: Call crawl_local_files(path, filters)
    CLF->>CLF: Walk directory (os.walk)
    loop For Each File
        CLF->>CLF: Check include patterns (fnmatch)
        CLF->>CLF: Check exclude patterns (fnmatch)
        CLF->>CLF: Check file size (os.path.getsize)
        alt File passes checks
            CLF->>CLF: Read file content
            CLF->>CLF: Add (path, content) to results
        else File fails checks
            CLF->>CLF: Skip file
        end
    end
    CLF-->>FL: Return list of (path, content)
    FL->>Shared: Store results in shared["files"]
    FL-->>WF: Node execution complete
```

The process for `FetchRepo` and `crawl_github_files` is similar, but instead of walking local directories, it uses the GitHub API to list files and download their content, applying the same filtering logic.

## A Peek at the Code

Let's look at simplified versions of the key components for local crawling:

**1. The `FetchLocal` Node (from `nodes.py`)**

This node orchestrates the local fetching process.

```python
# --- Simplified from nodes.py ---
import os
from pocketflow import Node
from utils.crawl_local_files import crawl_local_files # The utility function

class FetchLocal(Node):
    # Step 1: Prepare - Get instructions from shared dictionary
    def prep(self, shared):
        repo_url = shared["repo_url"] # Where to look
        include_patterns = shared["include_patterns"] # What to include
        exclude_patterns = shared["exclude_patterns"] # What to exclude
        max_file_size = shared["max_file_size"]       # Size limit

        # Return the needed info for the execution step
        return {
            "repo_url": repo_url,
            "include_patterns": include_patterns,
            "exclude_patterns": exclude_patterns,
            "max_file_size": max_file_size,
            "use_relative_paths": True # Keep paths clean
        }

    # Step 2: Execute - Call the librarian utility
    def exec(self, prep_res):
        print(f"Crawling local directory: {prep_res['repo_url']}...")
        # Call the helper function with the prepared arguments
        result = crawl_local_files(
            repo_url=prep_res["repo_url"],
            include_patterns=prep_res["include_patterns"],
            exclude_patterns=prep_res["exclude_patterns"],
            max_file_size=prep_res["max_file_size"],
            use_relative_paths=prep_res["use_relative_paths"]
        )
        # Get the list of files: [(path1, content1), (path2, content2), ...]
        files_list = list(result.get("files", {}).items())
        print(f"Fetched {len(files_list)} files.")
        return files_list # Return the list of fetched files

    # Step 3: Post-process - Store the results
    def post(self, shared, prep_res, exec_res):
        # Store the list of (path, content) tuples in the shared dictionary
        shared["files"] = exec_res
```

*   `prep`: Reads the configuration (`repo_url`, filters) provided initially (Chapter 1) from the `shared` dictionary.
*   `exec`: Calls the actual crawling function `crawl_local_files` with the configuration.
*   `post`: Takes the result from `exec` (the list of files) and saves it back into the `shared` dictionary under the key `"files"`.

**2. The `crawl_local_files` Utility (from `utils/crawl_local_files.py`)**

This is the function that does the actual walking and filtering.

```python
# --- Simplified from utils/crawl_local_files.py ---
import os
import fnmatch # For pattern matching (*.py, tests/*)

def crawl_local_files(repo_url, include_patterns, exclude_patterns, max_file_size, use_relative_paths):
    files = {} # Dictionary to store path -> content
    skipped_files = []

    # Function to check include/exclude patterns
    def should_include_file(rel_path, filename):
        # Check include patterns (like *.py)
        include_ok = not include_patterns or \
                     any(fnmatch.fnmatch(filename, pattern) for pattern in include_patterns)
        if not include_ok: return False

        # Check exclude patterns (like tests/*)
        exclude_ok = not exclude_patterns or \
                     not any(fnmatch.fnmatch(rel_path, pattern) for pattern in exclude_patterns)
        return exclude_ok

    # Walk through the directory
    for root, _, filenames in os.walk(repo_url):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            # Get path relative to the starting directory
            rel_path = os.path.relpath(file_path, repo_url)

            # Apply filters
            if not should_include_file(rel_path, filename):
                # print(f"Skipping {rel_path}: Filtered out by patterns")
                continue

            try:
                file_size = os.path.getsize(file_path)
                if file_size > max_file_size:
                    # print(f"Skipping {rel_path}: Too large ({file_size} bytes)")
                    skipped_files.append((rel_path, file_size))
                    continue

                # Read the file content if it passes all checks
                with open(file_path, "r", encoding="utf-8") as f:
                    files[rel_path] = f.read()
                    # print(f"Read: {rel_path}")

            except Exception as e:
                print(f"Error reading {rel_path}: {e}")

    # Return the dictionary of files and some stats
    return {"files": files, "stats": {"skipped_count": len(skipped_files)}}
```

*   `os.walk`: This standard Python function iterates through all directories and files.
*   `fnmatch.fnmatch`: Used to check if a filename or path matches the wildcard patterns (like `*.py` or `tests/*`).
*   `os.path.getsize`: Checks the file size in bytes.
*   `open(...)`: Reads the content of the files that pass the filters.

The result is a dictionary `files` where keys are the relative paths (like `src/main.py`) and values are the text content of those files. The `FetchLocal` node converts this into a list of tuples stored in `shared["files"]`.

## Conclusion

You've now learned about the Codebase Crawler, our digital librarian! It's responsible for the crucial first step of fetching the source code, whether it's from GitHub or your local machine. You saw how it uses the `repo_url` to know where to look and applies include/exclude patterns and size limits (provided via command-line arguments) to retrieve only the relevant files.

The output of this stage is a clean list of file paths and their content, stored in `shared["files"]`, ready for the next steps like analysis ([Chapter 3: LLM Analysis Engine](03_llm_analysis_engine.md)) and tutorial writing ([Chapter 2: Tutorial Generation](02_tutorial_generation.md)).

But how are all these steps (fetching, analyzing, writing) connected and managed? How does the system ensure they run in the right order? That's orchestrated by the **Workflow Pipeline (PocketFlow)**, which we'll dive into in the next chapter!

Let's move on to [Chapter 5: Workflow Pipeline (PocketFlow)](05_workflow_pipeline__pocketflow_.md).
```

---

Generated by [AI Codebase Knowledge Builder](https://github.com/The-Pocket/Tutorial-Codebase-Knowledge)