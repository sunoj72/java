import os
import fnmatch
from typing import Union, Set, List, Dict, Tuple, Any

def crawl_local_files(
    repo_url, 
    max_file_size: int = 1 * 1024 * 1024,  # 1 MB
    use_relative_paths: bool = False,
    include_patterns: Union[str, Set[str]] = None,
    exclude_patterns: Union[str, Set[str]] = None
):
    """
    Crawl files from a local directory.
    
    Args:
        repo_url (str): Path to the local directory.
        max_file_size (int, optional): Maximum file size in bytes to download (default: 1 MB)
        use_relative_paths (bool, optional): If True, file paths will be relative to the specified directory.
        include_patterns (str or set of str, optional): Pattern or set of patterns specifying which files to include (e.g., "*.py", {"*.md", "*.txt"}).
                                                       If None, all files are included.
        exclude_patterns (str or set of str, optional): Pattern or set of patterns specifying which files to exclude.
                                                       If None, no files are excluded.
    
    Returns:
        dict: Dictionary with files and statistics
    """
    # Convert single pattern to set
    if include_patterns and isinstance(include_patterns, str):
        include_patterns = {include_patterns}
    if exclude_patterns and isinstance(exclude_patterns, str):
        exclude_patterns = {exclude_patterns}
    
    files = {}
    skipped_files = []
    
    def should_include_file(file_path: str, file_name: str) -> bool:
        """Determine if a file should be included based on patterns"""
        # If no include patterns are specified, include all files
        if not include_patterns:
            include_file = True
        else:
            # Check if file matches any include pattern
            include_file = any(fnmatch.fnmatch(file_name, pattern) for pattern in include_patterns)
        
        # If exclude patterns are specified, check if file should be excluded
        if exclude_patterns and include_file:
            # Exclude if file matches any exclude pattern
            exclude_file = any(fnmatch.fnmatch(file_path, pattern) for pattern in exclude_patterns)
            return not exclude_file
        
        return include_file
    
    
    if not os.path.isdir(repo_url):
        print(f"Error: '{repo_url}' is not a valid directory.")
        return {
            "files": files,
            "stats": {
                "downloaded_count": 0,
                "skipped_count": 0,
                "skipped_files": [],
                "base_path": None,
                "include_patterns": include_patterns,
                "exclude_patterns": exclude_patterns
            }
        }
    
    
    for root, _, filenames in os.walk(repo_url):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            
            if use_relative_paths:
                rel_path = os.path.relpath(file_path, repo_url)
            else:
                rel_path = file_path
            
            if not should_include_file(rel_path, filename):
                print(f"Skipping {rel_path}: Does not match include/exclude patterns")
                continue
            
            try:
                file_size = os.path.getsize(file_path)
                if file_size > max_file_size:
                    skipped_files.append((rel_path, file_size))
                    print(f"Skipping {rel_path}: File size ({file_size} bytes) exceeds limit ({max_file_size} bytes)")
                    continue
                
                with open(file_path, "r", encoding="utf-8") as f:
                    files[rel_path] = f.read()
                    print(f"Read: {rel_path} ({file_size} bytes)")
            
            except Exception as e:
                print(f"Error reading {rel_path}: {e}")
    
    return {
        "files": files,
        "stats": {
            "downloaded_count": len(files),
            "skipped_count": len(skipped_files),
            "skipped_files": skipped_files,
            "base_path": repo_url if use_relative_paths else None,
            "include_patterns": include_patterns,
            "exclude_patterns": exclude_patterns
        }
    }

if __name__ == "__main__":
   # Example usage:
    repo_url = "."  # Current directory
    
    result = crawl_local_files(
        repo_url,
        max_file_size=1 * 1024 * 1024,  # 1 MB
        use_relative_paths=True,
        include_patterns={"*.py", "*.md"}
    )
    
    files = result["files"]
    stats = result["stats"]
    
    print(f"\nCrawled {stats['downloaded_count']} files.")
    print(f"Skipped {stats['skipped_count']} files due to size limits or patterns.")
    print(f"Base path for relative paths: {stats['base_path']}")
    print(f"Include patterns: {stats['include_patterns']}")
    print(f"Exclude patterns: {stats['exclude_patterns']}")
    
    # Display all file paths in the dictionary
    print("\nFiles in dictionary:")
    for file_path in sorted(files.keys()):
        print(f"  {file_path}")
    
    # Example: accessing content of a specific file
    if files:
        sample_file = next(iter(files))
    
